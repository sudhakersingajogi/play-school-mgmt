<!DOCTYPE html>
<html lang="en">
  <head>
  <base href="<?PHP echo base_url(); ?>">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>TSM</title>

    <!-- Bootstrap CSS -->    
    <link href="resources/template-assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="resources/template-assets/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="resources/template-assets/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="resources/template-assets/css/font-awesome.min.css" rel="stylesheet" />    
    <!-- full calendar css-->
    <!-- owl carousel -->
    <!-- Custom styles -->
    <link href="resources/template-assets/css/style.css" rel="stylesheet">
    <link href="resources/template-assets/css/style-responsive.css" rel="stylesheet" />
    
        <link href="resources/custom-assests/css/style.css" rel="stylesheet">

    <!-- =======================================================
        Theme Name: NiceAdmin
        Theme URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
        Author: BootstrapMade
        Author URL: https://bootstrapmade.com
    ======================================================= -->
    
        <link rel="stylesheet" href="resources/custom-assests/css/jquery-ui.css" />

<style>
.ui-state-default { text-align:center!important; }
.ui-datepicker td  { padding:5px!important;}
.err-msg{color:red;}
.err-border{ border:1px solid #F00;}
.required{color:red!important;}

.ui-datepicker-today
{
    background: rgba(255, 152, 0, 0.18) !important;
    border-radius: 50% !important;	
}

.filtersection div
{
	margin:10px !important;

}
.filtersection
{
	margin-bottom:0px !important;
}

.doc_details
{
	
	margin-top:30px;
	border-top:2px solid rgba(167, 172, 178, 0.23);
	padding-top:15px;
	display:none;

}

.doc_details .doc_child{
	margin-bottom:10px;
}


.err-border{border:1px solid #F00;}
#ui-datepicker-div{ z-index:22 !important;}

.assign-err
{
	margin-top:6px !important;	
	color:#F00 !important;
}

.addmore, .addmore_students
{
	    padding: 6px;
    background: #09C;
    border-radius: 28%;
    color: #fff;
	width:3%;
	cursor:pointer;
}

.addmore span, .addmore_students span
{
	margin-left:2px;	
	font-weight:bolder;

}


.remore_subject, .remove_students, .remove_subjects
{
    padding: 6px;
    background: #F00;
    border-radius: 28%;
    color: #fff;
	width:3%;
	cursor:pointer;
}

.remore_subject span, .remove_students span, .remove_subjects span
{
	margin-left:2px;	
	font-weight:bolder;

}

#subjects{ height:290px !important; }

#sidebar{width:210px !important; }

.wrapper{ margin-left:14px !important; width:98% !important; }

.car_del{
	position:absolute;
	right:0px;
	cursor:pointer;

	/*padding:8px;*/
	line-height:40px;
	text-align:center;
	width:40px;
	height:40px;
	
	font-size:25px !important;
	border-radius:200px;
	color:#f00;
	font-weight:750;
	z-index:9999999;
    background: #fff;
}

.calendar { width:100%; }
.months{
	position:relative;
}
.next_div{
	position:absolute;
	top:150px;
	right:-12px;
	
	background:#eee;
}
.next_div i{
	padding:10px ;
	background:#2196F3;
	color:#fff;
}
.pre_div{
	
	position:absolute;
	top:150px;
	left:0px;
	
	background:#eee;
}
.pre_div i{
	padding:10px ;
	background:#2196F3;
	color:#fff;
}



.calendar td { 	cursor:pointer; text-align:center; }
.calendar th {  text-align:center; padding-bottom:10px; padding-top:10px; }

.calendar th a { background:#09F; padding:5px; width:10px; color:#fff;}

.calendar
{
	
	padding:15px; 
	background:#eee;	
	text-align:center;
	border:1px solid #fff;

}	

.calendar .day
{
	
	padding:15px; 
	background:#eee;	
	text-align:center;
	border:1px solid #fff;

}	


.calendar .day:hover
{
	background:#FC3;
	color:#000;
	font-weight:bold;	
}	



.calendar .today
{
	color:#000;
	border:1px solid #fff;
	
	
	padding:15px; 
	background:rgba(255, 193, 7, 0.59);	
	text-align:center;
	
}	


.months{ float:left; margin-right:0px; }

.calendar:nth-child(even) {
{
	width:10px; 
	padding:15px; 
	background:#FC3!important;	
	text-align:center;
	border:1px solid #fff;

}	

.calendar td.day a{ background:#C69!important;}
.event_da label{

	float:left !important;
}
.event_da .form-control{
	width:85%;
}


</style>
  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
     
      
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
            <a class="logo">School <span class="lite">Application</span></a>
            <!--logo end-->

            

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">
                    
                    <!-- task notificatoin start -->
                  <!--   <li id="task_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="icon-task-l"></i>
                            <span class="badge bg-important">6</span>
                        </a>
                        <ul class="dropdown-menu extended tasks-bar">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 6 pending letter</p>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Design PSD </div>
                                        <div class="percent">90%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
                                            <span class="sr-only">90% Complete (success)</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">
                                            Project 1
                                        </div>
                                        <div class="percent">30%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
                                            <span class="sr-only">30% Complete (warning)</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Digital Marketing</div>
                                        <div class="percent">80%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            <span class="sr-only">80% Complete</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Logo Designing</div>
                                        <div class="percent">78%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="78" aria-valuemin="0" aria-valuemax="100" style="width: 78%">
                                            <span class="sr-only">78% Complete (danger)</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Mobile App</div>
                                        <div class="percent">50%</div>
                                    </div>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar"  role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                            <span class="sr-only">50% Complete</span>
                                        </div>
                                    </div>

                                </a>
                            </li>
                            <li class="external">
                                <a href="#">See All Tasks</a>
                            </li>
                        </ul>
                    </li> -->
                    <!-- task notificatoin end -->
                    <!-- inbox notificatoin start-->
                   <!--  <li id="mail_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="icon-envelope-l"></i>
                            <span class="badge bg-important">5</span>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 5 new messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="resources/template-assets/img/avatar-mini.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Greg  Martin</span>
                                    <span class="time">1 min</span>
                                    </span>
                                    <span class="message">
                                        I really like this admin panel.
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="resources/template-assets/img/avatar-mini2.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Bob   Mckenzie</span>
                                    <span class="time">5 mins</span>
                                    </span>
                                    <span class="message">
                                     Hi, What is next project plan?
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="resources/template-assets/img/avatar-mini3.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Phillip   Park</span>
                                    <span class="time">2 hrs</span>
                                    </span>
                                    <span class="message">
                                        I am like to buy this Admin Template.
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="resources/template-assets/img/avatar-mini4.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Ray   Munoz</span>
                                    <span class="time">1 day</span>
                                    </span>
                                    <span class="message">
                                        Icon fonts are great.
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">See all messages</a>
                            </li>
                        </ul>
                    </li> -->
                    <!-- inbox notificatoin end -->
                    <!-- alert notification start-->
                  
                   <li id="alert_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                            <i class="icon-bell-l"></i>
                            <span class="badge bg-important">7</span>
                        </a>
                        <ul class="dropdown-menu extended notification">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 4 new notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-primary"><i class="icon_profile"></i></span> 
                                    Friend Request
                                    <span class="small italic pull-right">5 mins</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-warning"><i class="icon_pin"></i></span>  
                                    John location.
                                    <span class="small italic pull-right">50 mins</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-danger"><i class="icon_book_alt"></i></span> 
                                    Project 3 Completed.
                                    <span class="small italic pull-right">1 hr</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-success"><i class="icon_like"></i></span> 
                                    Mick appreciated your work.
                                    <span class="small italic pull-right"> Today</span>
                                </a>
                            </li>                            
                            <li>
                                <a href="#">See all notifications</a>
                            </li>
                        </ul>
                    </li>
                    <!-- alert notification end-->
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                               <!-- <img alt="" src="resources/template-assets/img/avatar1_small.jpg">-->
                                <i class="fa fa-user"></i>
                            </span>
                            <span class="username"><?PHP echo ucwords($this->session->userdata('Admin'));?></span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            
                            <li class="eborder-top">
                                <a href="<?PHP echo base_url('logout')?>"><i class="icon_profile"></i> Logout</a>
                            </li>
                            <!-- 
                            <li class="eborder-top">
                                <a href="#"><i class="icon_profile"></i> My Profile</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_clock_alt"></i> Timeline</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                            </li>
                            <li>
                                <a href="login.html"><i class="icon_key_alt"></i> Log Out</a>
                            </li>
                            <li>
                                <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                            </li>
                            <li>
                                <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                            </li> -->
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->

      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
				  
                  <?PHP $uri_segm = $this->uri->segment(1); ?>
                  
                  <li class="sub-menu">

                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-class' ||  $uri_segm== 'view-classes' || $uri_segm== 'edit-class'){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Classes </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-class' ||  $uri_segm== 'view-classes' || $uri_segm== 'edit-class'){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-class' ||  $uri_segm== 'view-classes' || $uri_segm== 'edit-class'){  echo 'style="overflow: hidden; display: block;"'; } ?> >
		<li><a class="" href="add-class" <?PHP if( $uri_segm== 'add-class' ){ echo 'style="background:#24303b"';  } ?> >Add class </a></li>
        <li><a class="" href="view-classes" <?PHP if( $uri_segm== 'view-classes' ){ echo 'style="background:#24303b"';  } ?>>View classes</a></li>
                          
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                  
                  
                  
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-section' ||  $uri_segm== 'view-sections' || $uri_segm== 'edit-section' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Section </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-section' ||  $uri_segm== 'view-sections' || $uri_segm== 'edit-section' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-section' ||  $uri_segm== 'view-sections' || $uri_segm== 'edit-section' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-section" <?PHP if( $uri_segm== 'add-section' ){ echo 'style="background:#24303b"';  } ?> >Add section </a></li>
	<li><a class="" href="view-sections" <?PHP if( $uri_segm== 'view-sections' || $uri_segm=='edit-section' ){ echo 'style="background:#24303b"';  } ?>>View sections</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  <li class="sub-menu">
                  
                  
                  
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-subjects' ||  $uri_segm== 'view-subjects' || $uri_segm== 'edit-subject' || $uri_segm== 'assign-subject-class' || $uri_segm== 'view-assigned-subjects' || $uri_segm=='edit-assigned-subject-class'  ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Subjects </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-subjects' ||  $uri_segm== 'view-subjects' || $uri_segm== 'edit-subject' ||  $uri_segm== 'assign-subject-class' || $uri_segm=='edit-assigned-subject-class' || $uri_segm== 'view-assigned-subjects' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-subjects' ||  $uri_segm== 'view-subjects' || $uri_segm== 'edit-subject' || $uri_segm== 'assign-subject-class' || $uri_segm=='edit-assigned-subject-class' || $uri_segm== 'view-assigned-subjects'  ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-subjects" <?PHP if( $uri_segm== 'add-subjects' ){ echo 'style="background:#24303b"';  } ?> >Add subject </a></li>
	<li><a class="" href="view-subjects" <?PHP if( $uri_segm== 'view-subjects' || $uri_segm=='edit-subject' ){ echo 'style="background:#24303b"';  } ?>>View subjects</a></li>
    
    <li><a class="" href="assign-subject-class" <?PHP if( $uri_segm== 'assign-subject-class'){ echo 'style="background:#24303b"';  } ?>>Assign class subjects</a></li>
    
     <li><a class="" href="view-assigned-subjects" <?PHP if( $uri_segm== 'view-assigned-subjects' || $uri_segm=='edit-assigned-subject-class' ){ echo 'style="background:#24303b"';  } ?>>View assigned subjects</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  
                  
                  
                  
                  <li class="sub-menu">
                  
                  <a href="javascript:;" <?PHP if( $uri_segm== 'add-teacher' ||  $uri_segm== 'view-teachers' || $uri_segm== 'edit-teacher' || $uri_segm== 'assign-teacher' ||  $uri_segm== 'view-assign-teachers' || $uri_segm== 'edit-assigned-teacher' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Teacher </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-teacher' ||  $uri_segm== 'view-teachers' || $uri_segm== 'edit-teacher' || $uri_segm== 'assign-teacher' ||  $uri_segm== 'view-assign-teachers' || $uri_segm== 'edit-assigned-teacher' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-teacher' ||  $uri_segm== 'view-teachers' || $uri_segm== 'edit-teacher' || $uri_segm== 'assign-teacher' ||  $uri_segm== 'view-assign-teachers' || $uri_segm== 'edit-assigned-teacher' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-teacher" <?PHP if( $uri_segm== 'add-teacher' ){ echo 'style="background:#24303b"';  } ?> >Add Teacher </a></li>
	<li><a class="" href="view-teachers" <?PHP if( $uri_segm== 'view-teachers' || $uri_segm=='edit-teacher' ){ echo 'style="background:#24303b"';  } ?>>View teacher</a></li>
    
    <li><a class="" href="assign-teacher" <?PHP if( $uri_segm== 'assign-teacher' ){ echo 'style="background:#24303b"';  } ?> >Assign Teacher </a></li>
	<li><a class="" href="view-assign-teachers" <?PHP if( $uri_segm== 'view-assign-teachers' || $uri_segm=='edit-assigned-teacher' ){ echo 'style="background:#24303b"';  } ?>>View assigned teachers</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  <li class="sub-menu">
                  
                  
                  
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-student' ||  $uri_segm== 'view-students' || $uri_segm== 'edit-student' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Student </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-student' ||  $uri_segm== 'view-students' || $uri_segm== 'edit-student' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-student' ||  $uri_segm== 'view-students' || $uri_segm== 'edit-student' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-student" <?PHP if( $uri_segm== 'add-student' ){ echo 'style="background:#24303b"';  } ?> >Add student </a></li>
	<li><a class="" href="view-students" <?PHP if( $uri_segm== 'view-students' || $uri_segm=='edit-student' ){ echo 'style="background:#24303b"';  } ?>>View students</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  <li class="sub-menu">
                  
                  
                  
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-fee-structure' ||  $uri_segm== 'view-fee-structure' || $uri_segm== 'edit-fee-structure' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Fee </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-fee-structure' ||  $uri_segm== 'view-fee-structure' || $uri_segm== 'edit-fee-structure' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-fee-structure' ||  $uri_segm== 'view-fee-structure' || $uri_segm== 'edit-fee-structure' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-fee-structure" <?PHP if( $uri_segm== 'add-fee-structure' ){ echo 'style="background:#24303b"';  } ?> >Add fee structure </a></li>
	<li><a class="" href="view-fee-structure" <?PHP if( $uri_segm== 'view-fee-structure' || $uri_segm=='edit-fee-structure' ){ echo 'style="background:#24303b"';  } ?>>View fee structure</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  
                  
                  
                  <li class="sub-menu">
                  
                  
                  
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-notification-to-student' ||  $uri_segm== 'view-notifications-to-student' || $uri_segm== 'edit-notification-to-student' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Notifications </span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-notification-to-student' ||  $uri_segm== 'view-notifications-to-student' || $uri_segm== 'edit-notification-to-student' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-notification-to-student' ||  $uri_segm== 'view-notifications-to-student' || $uri_segm== 'edit-notification-to-student' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-notification-to-student" <?PHP if( $uri_segm== 'add-notification-to-student' ){ echo 'style="background:#24303b"';  } ?> >Add Notification</a></li>
	<li><a class="" href="view-notification-to-student" <?PHP if( $uri_segm== 'view-notification-to-student' || $uri_segm=='edit-notification-to-student' ){ echo 'style="background:#24303b"';  } ?>>View notifications</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-homework-to-student' ||  $uri_segm== 'view-homework-to-student' || $uri_segm== 'edit-home-work' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Home Works</span>
                          <span class="menu-arrow  <?PHP if($uri_segm== 'add-homework-to-student' ||  $uri_segm== 'view-homework-to-student' || $uri_segm== 'edit-home-work' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-homework-to-student' ||  $uri_segm== 'view-homework-to-student' || $uri_segm== 'edit-home-work' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-homework-to-student" <?PHP if( $uri_segm== 'add-homework-to-student' ){ echo 'style="background:#24303b"';  } ?> >Add home work</a></li>
	<li><a class="" href="view-homework-to-student" <?PHP if( $uri_segm== 'view-homework-to-student' || $uri_segm=='edit-home-work' ){ echo 'style="background:#24303b"';  } ?>>View home works</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  
                  
                  <li class="sub-menu">
                  
                  
                  
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-student-activity' ||  $uri_segm== 'view-student-activities' || $uri_segm== 'edit-student-activity' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Activities</span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-student-activity' ||  $uri_segm== 'view-student-activities' || $uri_segm== 'edit-student-activity' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-student-activity' ||  $uri_segm== 'view-student-activities' || $uri_segm== 'edit-student-activity' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-student-activity" <?PHP if( $uri_segm== 'add-student-activity' ){ echo 'style="background:#24303b"';  } ?> >Add student activity</a></li>
	<li><a class="" href="view-student-activities" <?PHP if( $uri_segm== 'view-student-activities' || $uri_segm=='edit-student-activity' ){ echo 'style="background:#24303b"';  } ?>>View student activity</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-celebration' ||  $uri_segm== 'view-celebrations' || $uri_segm== 'edit-celebration' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Celebrations</span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-celebration' ||  $uri_segm== 'view-celebrations' || $uri_segm== 'edit-celebration' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-celebration' ||  $uri_segm== 'view-celebrations' || $uri_segm== 'edit-celebration' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-celebration" <?PHP if( $uri_segm== 'add-celebration' ){ echo 'style="background:#24303b"';  } ?> >Add a celebration</a></li>
	<li><a class="" href="view-celebrations" <?PHP if($uri_segm== 'view-celebrations' || $uri_segm== 'edit-celebration' ){ echo 'style="background:#24303b"';  } ?>>View celebrations</a></li>
                          
                          
                      </ul>
                  </li>
                  
                  
                  <li class="sub-menu">
                      <a href="javascript:;" <?PHP if( $uri_segm== 'add-exam' ||  $uri_segm== 'view-exams' || $uri_segm== 'edit-exam' ){  echo 'style="background:#3975b6"';  }?>  >
                          <i class="icon_document_alt"></i>
                          <span>Manage Exams</span>
                          <span class="menu-arrow  <?PHP if( $uri_segm== 'add-exam' ||  $uri_segm== 'view-exams' || $uri_segm== 'edit-exam' ){ echo 'arrow_carrot-down'; }else echo 'arrow_carrot-right'; ?>"></span>
                      </a>
                      <ul class="sub"  <?PHP if( $uri_segm== 'add-exam' ||  $uri_segm== 'view-exams' || $uri_segm== 'edit-exam' ){  echo 'style="overflow: hidden; display: block;"'; } ?> >
	
    <li><a class="" href="add-exam" <?PHP if( $uri_segm== 'add-exam' ){ echo 'style="background:#24303b"';  } ?> >Add a exam</a></li>
	<li><a class="" href="view-exams" <?PHP if($uri_segm== 'view-exam' || $uri_segm== 'edit-exam' ){ echo 'style="background:#24303b"';  } ?>>View exams</a></li>
                          
                          
                      </ul>
                  </li>

                         
                         
                  
                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
