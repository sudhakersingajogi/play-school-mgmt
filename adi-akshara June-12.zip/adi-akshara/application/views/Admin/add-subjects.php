
<section id="main-content">
  <section class="wrapper">  
 <div class="row">
				<div class="col-lg-12">
                
                <ol class="breadcrumb">

					<li><i class="fa fa-laptop"></i>Add Subjects</li>

					</ol>
                
                </div>
			</div>

	<div class="row">
  
                  <div class="col-lg-12">
                 
                      <section class="panel">
                          <header class="panel-heading">
                             Add Subjects
                          </header>
                          <div class="panel-body">

                              <div class="form col-lg-9">
                                  <form class="form-validate form-horizontal " id="add_student_form" method="post" action="">
                                      
                                   <div class="form-group ">
                                          <label for="TotalSubjects" class="control-label col-lg-4">Total Subjects<span class="required">*</span></label>
                                          <div class="col-lg-2">
											<input type="text" class="form-control" name="TotalSubjects" id="TotalSubjects" />
                                          </div>
                                          <div class="col-lg-2">
											<input type="button" class="btn btn-danger btn-block" name="Createsubject" id="Createsubject" value="Create subject " />
                                          </div>
                                           <div class="col-lg-2 err-msg assign-err"><span class="TotalSubjects_err"></span> </div>
                                      </div>
                                      
                                      
                                      <div class="form-group subjectsdiv">
                                         
                                         
                                      </div>
                                      
                                      
                                      <div class="form-group">
                                          <div class="col-lg-offset-4 col-lg-8">
                                             
                                             <input type="button" class="btn btn-primary " edit_add='add' name="addsubjects" id="addsubjects" value="Add subjects" />
                                             <span style="margin-left:20px" class="add-student-resp" ></span>
                                           
                                          </div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>          
              
</section          
      ></section>