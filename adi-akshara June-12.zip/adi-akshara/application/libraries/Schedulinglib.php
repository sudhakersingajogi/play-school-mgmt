<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Schedulinglib
	{
		public function __construct()
		{
			$this->CI =& get_instance();
			
			$this->CI->load->helper('url');
			$this->CI->config->item('base_url');
			$this->CI->load->database();	
			$this->CI->load->model('Commonmodel');
			$this->CI->load->library('pagination');
		}
		
		
		public function getcelebevents($yr,$mnth)
		{
			
			$yr1=date('Y');
			$yr2=date('Y');
					
			if( $mnth<9 && $mnth>=6 )
				{

					
					$mtn = $mnth;
					
					$curmnth  = "0".$mnth;
					
					$nextmnth =	$mnth+1;
					$nextmnth = "0".$nextmnth;
					
					$onemoremonth = $mnth+2;
					$onemoremonth = "0".$onemoremonth;
					
					$this->CI->db->like('Celebration_Date', $yr1."-".$curmnth );
					$this->CI->db->or_like('Celebration_Date', $yr1."-".$nextmnth );
					$this->CI->db->or_like('Celebration_Date', $yr1."-".$onemoremonth ); 

				}
			else
			{
				if($mnth==9)
				{
					$curmnth  = "09";
					$nextmnth =	"10";
					$onemoremonth = "11";
					
					$this->CI->db->like('Celebration_Date', $yr1."-".$curmnth );
					$this->CI->db->or_like('Celebration_Date', $yr1."-".$nextmnth );
					$this->CI->db->or_like('Celebration_Date', $yr1."-".$onemoremonth ); 
					
					
				}
				else
				{
					$curmnth  = "12";
					$nextmnth =	"01";
					$onemoremonth = "02";
						
					if($mnth<=12)
					{
						$yr1=date('Y');
						$yr2=date('Y')+1;
						
						$this->CI->db->like('Celebration_Date', $yr1."-".$curmnth );
						$this->CI->db->or_like('Celebration_Date', $yr2."-".$nextmnth );
						$this->CI->db->or_like('Celebration_Date', $yr2."-".$onemoremonth );
						
						
					}
					else
					{
						$curmnth  = "03";
						$nextmnth =	"04";

						
						$yr1=date('Y')+1;
						$yr2=date('Y')+1;
				
						$this->CI->db->like('Celebration_Date', $yr1."-".$curmnth );
						$this->CI->db->or_like('Celebration_Date', $yr2."-".$nextmnth );

						
					}
					
					 


				}
			}//else ends here
			
			$this->CI->db->select("month(Celebration_Date) as mnth, day(Celebration_Date) as day, CelebId, Celebration_Text ");
			$this->CI->db->order_by("month(Celebration_Date)","ASC");
//			$this->CI->db->order_by("year(Celebration_Date)","ASC");
			$qry = $this->CI->db->get('celebrations');
	//		return $this->CI->db->last_query();
			
			$ourput_arr = array();
			$prevMonth = "0";
			if($qry->num_rows()>0)
			{
				foreach($qry->result() as $celebrations)
				{
					$ourput_arr[$celebrations->mnth][$celebrations->day] =$celebrations->Celebration_Text."/||||".$celebrations->CelebId;
				}
				return $ourput_arr;
			}
			else
				return "0";
			
			
		}
		
	}//class ends here
?>