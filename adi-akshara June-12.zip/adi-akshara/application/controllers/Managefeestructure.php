<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Managefeestructure extends CI_Controller 
{

	 public function __construct()
		{
			parent::__construct();
			date_default_timezone_set("Asia/Kolkata");
			define('HEADER','Admin/header');
			define('FOOTER','Admin/footer');
			
			$this->load->model('Commonmodel');
			
			if( $this->session->userdata('Admin')!='' &&  $this->session->userdata('Role')!='' && $this->uri->segment(1)=='') { redirect(base_url()); }
			else if( $this->uri->segment(1)!='') 
					{ 

						if($this->session->userdata('Admin')=='' ||  $this->session->userdata('Role')=='')
						{
							redirect(base_url() );
						}
					}

		if( $this->uri->segment(1)=='view-students')
		{
			echo '<div style="height:1px; background-color:#1a2732"> </div>';

		}
		else
		{
			//echo $this->uri->segment(1);
			$this->session->set_userdata('ClassName','');
			$this->session->set_userdata('Section','');
			
		}
			
			
		}
		
	public function pagenotfound()
	{
		$this->load->view(HEADER);
		$this->load->view('Admin/pagenotfound');
		$this->load->view(FOOTER);	
	}

	public function loadformrules($configItem)
	{
		return $this->config->item($configItem);
	}
	
	public function addfeestructure()
	{
		$this->load->view(HEADER);
		$cond = array();
		
		$data['classes'] = $this->Commonmodel->getrows($table='newclass',$cond,$order_by='',$order_by_field='',$limit='');
	
		
		if( $this->input->post('add_fee_structure') )
		{
			$this->form_validation->set_rules( $this->loadformrules('addfeestructure') );
			
			if( $this->form_validation->run() === false )
			{
				$this->load->view('Admin/add-fee-structure',$data);		
			}
			else
			{
				$table = 'schoolfee';	
				$insertdata = array();
				
				$insertdata['Class'] = $this->input->post('ClassName');
				$insertdata['AcademicYear'] = $this->input->post('AcademicYear');
				$insertdata['MonthlyFee'] = $this->input->post('MonthlyFee');
				
				$insertdata['QuarterlyFee'] = $this->input->post('QuarterlyFee');
				$insertdata['HalfyearlyFee'] = $this->input->post('HalfyearlyFee');
				$insertdata['AnnualFee'] = $this->input->post('AnnualFee');
				
				$insertdata['Lastupdated'] = time();
				
				if( $this->Commonmodel->insertdata($table,$insertdata) )
				{
					$msg = "<div class='alert alert-success'>Fee added successfully</div>";
					$this->session->set_flashdata('fee-added',$msg);
				}
				else
				{
					$msg = "<div class='alert alert-danger'>Unable to add fee structure</div>";
					$this->session->set_flashdata('fee-added',$msg);
				}
				
				redirect(base_url('add-fee-structure'));

			}
		}
		else
		$this->load->view('Admin/add-fee-structure',$data);
		
		$this->load->view(FOOTER);
	}

	public function viewfeestructure()
	{
		$this->load->view(HEADER);
		
		$table='schoolfee'; 
		$cond=array();
		$baseurl='view-fee-structure';
		$perpage=2;
		$order_by_field='FeeId';
		$datastring='feestructure';
		$pagination_string = 'pagination_string';
		
		$data = $this->tsmpaginate->feestructurepagination($table,$cond,$baseurl,$perpage,$order_by_field,$datastring,$pagination_string);
		
		$data['classes'] = $this->Commonmodel->getrows($table='newclass',$cond,$order_by='',$order_by_field='',$limit='');
		$data['perpage']= $perpage;
		$this->load->view('Admin/view-fee-structure',$data);
				
		$this->load->view(FOOTER);		
	}

	
	public function editfeestructure()
	{
		$this->load->view(HEADER);
		$cond=array();
		
		$data['classes'] = $this->Commonmodel->getrows($table='newclass',$cond,$order_by='',$order_by_field='',$limit='');	
		
		$cond = array();
		$table = 'schoolfee';
		
		$cond['FeeId'] =  $this->uri->segment(2);
		
		$feedetails = $this->Commonmodel->get_single_row($table,$cond,$order_by='',$order_by_field='',$limit='');
		if($feedetails!='0')
		{	
		
			if( $this->input->post('update_fee_structure') )
			{
				
			$this->form_validation->set_rules( $this->loadformrules('addfeestructure') );
			
			if( $this->form_validation->run() === false )
			{
				$this->load->view('Admin/add-fee-structure',$data);		
			}
			else
			{
				$table = 'schoolfee';	
				$setdata = array();
				
				$setdata['Class'] = $this->input->post('ClassName');
				$setdata['AcademicYear'] = $this->input->post('AcademicYear');
				$setdata['MonthlyFee'] = $this->input->post('MonthlyFee');
				
				$setdata['QuarterlyFee'] = $this->input->post('QuarterlyFee');
				$setdata['HalfyearlyFee'] = $this->input->post('HalfyearlyFee');
				$setdata['AnnualFee'] = $this->input->post('AnnualFee');
				
				$setdata['Lastupdated'] = time();
				
				$cond = array();
				$cond['FeeId'] =  $this->uri->segment(2);
				
				if( $this->Commonmodel->updatedata($table,$setdata,$cond) )
				{
					$msg = "<div class='alert alert-success'>Fee details updated successfully</div>";
					$this->session->set_flashdata('fee-details-updated',$msg);
				}
				else
				{
					$msg = "<div class='alert alert-danger'>Unable to update fee details structure</div>";
					$this->session->set_flashdata('fee-details-updated',$msg);
				}
				
				redirect(base_url('edit-fee-structure')."/".$this->uri->segment(2));

			}
		
			}
		
			$data['feedetails'] = $feedetails;
			$this->load->view('Admin/edit-fee-structure',$data);
		}
		else
		{
			$data['routeto'] = 'view-fee-structure';
			$this->load->view('Admin/pagenotfound',$data);	
		}
		

				
		$this->load->view(FOOTER);		
	}



//callbacks starts here

	public function checkclass_select($cls)
	{
		if($cls=='0')
		{
			$this->form_validation->set_message('checkclass_select',"Select class");
			return false;
		}
		else
			return true;
	}
	
	public function checkacademicyear_select($academicyear)
	{
		if($academicyear=='0')
		{
			$this->form_validation->set_message('checkacademicyear_select',"Academic year");
			return false;
		}
		else
			return true;
	}

//callbacks ends here
	
}//class ends here
