<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Schedulingdispatcher extends CI_Controller 
{

	 public function __construct()
		{
			parent::__construct();
			date_default_timezone_set("Asia/Kolkata");
			
			$this->load->model('Commonmodel');
			
		}//constructor stARTS HERE
		
	
	
	public function striptags($posted_data)
		{
			
		
			$requested_from =  $_SERVER['HTTP_REFERER'];
			
			
		if( strpos($requested_from, 'localhost') !== false || strpos($requested_from, 'trillionit.in') !== false)
			//if( strpos($requested_from, 'trillionit.in') !== false)
			{
			//foreach($posted_data as $key=>$val) { $_POST[$key] = htmlentities( stripslashes(strip_tags($val)), ENT_QUOTES | ENT_HTML5, 'UTF-8'); }
			foreach($posted_data as $key=>$val) 
			{ 
			$str = stripslashes(str_replace("'","",$val));
			//The following to sanitize a string. It will both remove all HTML tags, and all characters with ASCII value > 127, from the string:
			$_POST[$key] = filter_var($str, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH); 
			
			}
			return $_POST;	
			}
			else
			echo "!!!! Access denied !!!!"; exit; 
		
		}
			
		public function addCelebration()
		{
			$postdata = $this->striptags($_POST);
			
			extract($postdata);
			
			
			$insertdata = array();
			$table = 'celebrations';
			
			$cel_date = date_create($cel_date);
			$cel_date = date_format($cel_date,'Y-m-d');
			
			
			$insertdata['Celebration_Date'] = $cel_date;
			$insertdata['Celebration_Text'] = $celebration;
			$insertdata['Lastupdated'] = time();
			
			if( $this->Commonmodel->insertdata($table,$insertdata))
				echo "1";
			else
				echo "0";
			
			
		}

		public function getcelebratation()
		{
			$postdata = $this->striptags($_POST);
			extract($postdata);
			
			$cond = array();
			$table ='celebrations';
			
			$cond['CelebId'] = $CelebId;
			$fields='date_format(Celebration_Date,"%d-%m-%Y") as Celebration_Date,Celebration_Text';
			$order_by='';
			$order_by_field='';
			$limit='';
			
			$data = $this->Commonmodel->getRows_fields($table,$cond,$fields,$order_by,$order_by_field,$limit);
			
			$output = array();
			
			if($data!='0')
			{
				foreach($data->result() as $res)
				{
					$output[] = array("Celebration_Date"=>$res->Celebration_Date,"Celebration_Text"=>$res->Celebration_Text,"CelebId"=>$CelebId);
				}
				echo json_encode($output);
			}
			else
			echo "0";
			
			
			
		}
		//getcelebrations ends here
		
		//updateCelebration starts here
		
		public function updateCelebration()
		{
			$postdata = $this->striptags($_POST);
			extract($postdata);
			
			$cond = array();
			$table ='celebrations';
			$insertdata = array();
			
			
			$cond['CelebId'] = $CelebId;
		
			$insertdata['Celebration_Text'] = $celebration;
			$insertdata['Lastupdated'] = time();
			
			if($this->Commonmodel->updatedata($table,$insertdata,$cond))
				echo "1";
			else
				echo "0";
			
		}
		
		//updateCelebration ends here
	
	public function addExam()
	{
		$postdata = $this->striptags($_POST);
		extract($postdata);
		
		//check whether same this examalready scheduled or not
		
		$cond = array();
		$table = 'examschedules';
		
		$cond['Exam'] =$ExamName;
		$cond['ClassName'] =$ClassName;
		$cond['ClassSection'] =$ClassSection;
		$cond['Subject'] =$Subject;
		
		$ExamDate = date_create($ExamDate);
		$ExamDate = date_format($ExamDate,'Y-m-d');
		
		$cond['ExamSchedule'] = $ExamDate;
		
		if( $this->Commonmodel->checkexists($table,$cond))
		{
			echo "-1";
		}
		else
		{
			$insertdata = array();
			
			
			$ExamDate = date_create($ExamDate);
			$ExamDate = date_format($ExamDate,'Y-m-d');
			
			$insertdata['Exam'] =$ExamName;
			$insertdata['ClassName'] =$ClassName;
			$insertdata['ClassSection'] =$ClassSection;
			$insertdata['Subject'] =$Subject;
			$insertdata['ExamSchedule'] = $ExamDate;
			
			$chkmonth = explode("-",$ExamDate); 
			$chkmnth = (int)$chkmonth[1];
			
			if($chkmnth>5 && $chkmnth<=12)
				$academicYear= $chkmonth[0]."-".($chkmonth[0]+1);
			else
				$academicYear= ($chkmonth[0]-1)."-".($chkmonth[0]);
			
			$insertdata['AcademicYear'] = $academicYear;
			
			$insertdata['LastUpdated'] = time();
			
			if( $this->Commonmodel->insertdata($table,$insertdata) )
				echo "1";
			else
				echo "0";
		}
		
		
		
	}
					
					
}//class ends here		