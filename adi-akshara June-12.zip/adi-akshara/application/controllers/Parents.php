<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parents extends CI_Controller 
{

	 public function __construct()
		{
			
			parent::__construct();
			date_default_timezone_set("Asia/Kolkata");
			define('HEADER','Parent/header');
			define('FOOTER','Parent/footer');
			
			$this->load->model('Commonmodel');
	
	$requested_from =  @$_SERVER['HTTP_REFERER'];

	define('HTTP_REFERER',$requested_from);
	
			
if( strpos($requested_from, 'localhost') !== false )
{
	
	if( $this->uri->segment(2)!='parent')
	{
		
		
			if( $this->session->userdata('parent')=='')
			{
				$parentname = $this->checkparentdetails();
				$this->session->set_userdata('parent',$parentname);
			}
			
			$cond = array();
			$table ='notifications';
			
			$StudentId = $this->session->userdata('StudentId');
			$Status = 'Unread';
			
			$where = "StudentId=".$StudentId." AND status='".$Status."' AND (DATEDIFF(CURRENT_DATE(), DATE(AddedOn)) >= 2 OR DATEDIFF(CURRENT_DATE(), DATE(AddedOn)) >= 0)";
			
			$this->db->where($where);
			$New_Notifications = $this->db->get($table);
			
			if($New_Notifications!='0')
				define("New_Notifications",$New_Notifications->num_rows() );
			else
				define("New_Notifications", '0' );
				
		
	}
}
else if(strpos(HTTP_REFERER, 'trillionit.in') !== false)
{
	if( $this->uri->segment(1)!='parent')
	{
		
		
			if( $this->session->userdata('parent')=='')
			{
				$parentname = $this->checkparentdetails();
				$this->session->set_userdata('parent',$parentname);
			}
			
			$cond = array();
			$table ='notifications';
			
			$StudentId = $this->session->userdata('StudentId');
			$Status = 'Unread';
			
			$where = "StudentId=".$StudentId." AND status='".$Status."' AND (DATEDIFF(CURRENT_DATE(), DATE(AddedOn)) >= 2 OR DATEDIFF(CURRENT_DATE(), DATE(AddedOn)) >= 0)";
			
			$this->db->where($where);
			$New_Notifications = $this->db->get($table);
			
			if($New_Notifications!='0')
				define("New_Notifications",$New_Notifications->num_rows() );
			else
				define("New_Notifications", '0' );
				
		
	}
}

			
		}
		
	public function checkparentdetails()
	{
		$cond = array();
		$table = 'parentdetails';
		
		$cond['StudentId'] = $this->session->userdata('StudentId');
		
		$Parentname = $this->Commonmodel->getAfield($table,$cond,$field='FatherName',$order_by='',$order_by_field='',$limit='');
		return $Parentname;
		
	}
		

	public function loadformrules($configItem)
	{
		return $this->config->item($configItem);
	}

		
	public function pagenotfound()
	{
		$this->load->view(HEADER,$data[New_Notifications]);
		$this->load->view('Parent/pagenotfound');
		$this->load->view(FOOTER);	
	}
	
	public function login()
	{
		$cond=array();
		$data['classes'] = $this->Commonmodel->getrows($table='newclass',$cond,$order_by='',$order_by_field='',$limit='');
		$this->load->view('Parent/login',$data);
	}
	
	public function dashboard()
	{
		$data = array();
		$data['New_Notifications'] = New_Notifications;	
		
		
		$this->load->view(HEADER,$data);
		$this->load->view(FOOTER);	
	}
	
	public function vieweditprofile()
	{
		$data = array();
		$data['New_Notifications'] = New_Notifications;	
		$this->load->view(HEADER,$data);
		
		$cond = array();
		$table = 'parentdetails';
		$cond['StudentId'] = $this->session->userdata('StudentId');
		
		if( $this->Commonmodel->checkexists($table,$cond))
		{
			$data['parent_details'] = $this->Commonmodel->get_single_row($table,$cond,$order_by='',$order_by_field='',$limit='');
		}
		else
		{
			$data['parent_details'] = '0';
		}
		
		if( $this->input->post('update_profile') )
		{
			$this->form_validation->set_rules($this->loadformrules('AddParentProfile'));
			
			if( $this->form_validation->run() === false)
			{
				$this->load->view('Parent/view-edit-profile',$data);
			}
			else
			{
				$table = 'parentdetails';
				if( $this->input->post('edit_add') =='add')
				{
					$insertdata = array();
					extract($_POST);
					
					$insertdata['StudentId'] = $StudentId;
					$insertdata['MotherName'] = $MotherName;
					
					$insertdata['FatherName'] = $FatherName;
					$insertdata['MotherHighestDegree'] = $MotherHighestDegree;
					
					$insertdata['FatherHighestDegree'] = $FatherHighestDegree;
					$insertdata['MotherOccupation'] = $MotherOccupation;
					
					$insertdata['FatherOccupation'] = $FatherOccupation;
					$insertdata['ContactNumber1'] = $ContactNumber1;
				
					$insertdata['ContactNumber2'] = $ContactNumber2;
					
					$insertdata['Address'] = $Address;
					$insertdata['Lastupdated'] = time();
					
					if( $this->Commonmodel->insertdata($table,$insertdata))
					{
						$msg = "<div class='alert alert-succes'><b>Parent profile created successfully</b></div>";	
						$this->session->set_flashdata('parentprofile',$msg);
					}
					else
					{
						$msg = "<div class='alert alert-danger'><b>Unable to create parent profile</b></div>";	
						$this->session->set_flashdata('parentprofile',$msg);
					}
					redirect(base_url('view-edit-profile'));
					
				}
				else
				{
					$setdata = array();
					$cond =array();
					
					extract($_POST);
					
					$cond['StudentId'] = $StudentId;
					
					$setdata['MotherName'] = $MotherName;
					
					$setdata['FatherName'] = $FatherName;
					$setdata['MotherHighestDegree'] = $MotherHighestDegree;
					
					$setdata['FatherHighestDegree'] = $FatherHighestDegree;
					$setdata['MotherOccupation'] = $MotherOccupation;
					
					$setdata['FatherOccupation'] = $FatherOccupation;
					$setdata['ContactNumber1'] = $ContactNumber1;
				
					$setdata['ContactNumber2'] = $ContactNumber2;
					
					$setdata['Address'] = $Address;
					$setdata['Lastupdated'] = time();
					
					if( $this->Commonmodel->updatedata($table,$setdata,$cond))
					{
						$msg = "<div class='alert alert-success'><b>Parent profile updated successfully</b></div>";	
						$this->session->set_flashdata('parentprofile',$msg);
					}
					else
					{
						$msg = "<div class='alert alert-danger'><b>Unable to update parent profile</b></div>";	
						$this->session->set_flashdata('parentprofile',$msg);
					}
					redirect(base_url('view-edit-profile'));
					
				}
			}
			
		}
		else
			$this->load->view('Parent/view-edit-profile',$data);
		
		$this->load->view(FOOTER);
	}
	

//vieweditchildprofile starts here

	public function vieweditchildprofile()
	{
		
		$data = array();
		$data['New_Notifications'] = @New_Notifications;	
		$this->load->view(HEADER,$data);
		
		//get the student first,last and bloodgroup
		
		$cond = array();
		$cond['StudentId'] = $this->session->userdata('StudentId');
		$table = 'students';
		$fields='Student, LastName, BloodGroup,ProfileIPic';
		
		$data['student_details'] = $this->Commonmodel->getRows_fields($table,$cond,$fields,$order_by='',$order_by_field='',$limit='');
		
		//get the Hobbies of this student
		
		$table = 'studenthobbies';
		$fields= 'Hobby,HobbyId';
		$data['hobbies_details'] = $this->Commonmodel-> getRows_fields($table,$cond,$fields,$order_by='ASC',$order_by_field='HobbyId',$limit='');
		
		//get the extracircular activities
		
		$table='extracircularactivities';
		$fields='ExtraActivity,ExtracActId';
		$data['Extracircular_details'] = $this->Commonmodel-> getRows_fields($table,$cond,$fields,$order_by='ASC',$order_by_field='ExtracActId',$limit='');
		
		//get the Identification Marks
		
		$table='identificationmarks';
		$fields='IdentificationMark,Markid';
		$data['identificationmarks_details'] = $this->Commonmodel-> getRows_fields($table,$cond,$fields,$order_by='ASC',$order_by_field='Markid',$limit='');
		
		
		
			$this->load->view('Parent/view-edit-child-profile',$data);	
		$this->load->view(FOOTER);
	}

//vieweditchildprofile ends hree
	
	public function viewadminnotifications()
	{
		$data = array();
		$data['New_Notifications'] = New_Notifications;	
		$this->load->view(HEADER,$data);
		
		if( strpos(HTTP_REFERER, 'localhost') !== false )
		{
			if($this->uri->segment(2)!='')
			$this->session->set_userdata('collapse','');	
		}
		else if(strpos(HTTP_REFERER, 'trillionit.in') !== false)	
		{
			if($this->uri->segment(2)!='')
			$this->session->set_userdata('collapse','');	
		}
			
		
		$table='notifications'; 
		
		$cond=array();
		
		$cond['noti.StudentId'] =  $this->session->userdata('StudentId');
		
		$baseurl='view-admin-notifications';
		$perpage=10;
		$order_by_field='NotificationId';
		$datastring='Notifications';
		$pagination_string = 'pagination_string';

		$AddedBy='Admin';
		$data = $this->tsmpaginate->notifstudentspagination($table,$cond,$baseurl,$perpage,$order_by_field,$datastring,$pagination_string,$AddedBy);
		
		$data['classes'] = $this->Commonmodel->getrows($table='newclass',array(),$order_by='',$order_by_field='',$limit='');
		$data['perpage']= $perpage;
		
		if($data['Notifications']=='0' )
		{
			$data['routeto'] = 'parent-dashboard';
			$this->load->view('Parent/pagenotfound');
		}
		else
		$this->load->view('Parent/view-admin-notifications',$data);
		
		$this->load->view(FOOTER);
	}
	
	public function addnotification()
	{
			
		$data = array();
		$data['New_Notifications'] = New_Notifications;	
		$this->load->view(HEADER,$data);
		
		if( strpos(HTTP_REFERER, 'localhost') !== false )
		{
			if($this->uri->segment(2)!='')
			$this->session->set_userdata('collapse','');	
		}
		else if(strpos(HTTP_REFERER, 'trillionit.in') !== false)	
		{
			if($this->uri->segment(2)!='')
			$this->session->set_userdata('collapse','');	
		}
			
		
		$table='notifications'; 
		
		$cond=array();
		
		$cond['noti.StudentId'] =  $this->session->userdata('StudentId');
		
		$baseurl='add-notification';
		$perpage=10;
		$order_by_field='NotificationId';
		$datastring='Notifications';
		$pagination_string = 'pagination_string';

		$AddedBy='Admin';
		$data = $this->tsmpaginate->notifstudentspagination($table,$cond,$baseurl,$perpage,$order_by_field,$datastring,$pagination_string,$AddedBy);
		
		$data['classes'] = $this->Commonmodel->getrows($table='newclass',array(),$order_by='',$order_by_field='',$limit='');
		$data['perpage']= $perpage;
		
		if($data['Notifications']=='0' )
		{
			$data['routeto'] = 'parent-dashboard';
			$this->load->view('Parent/pagenotfound');
		}
		else
		$this->load->view('Parent/add-notification',$data);
			
			$this->load->view(FOOTER);
			
	}
	
	public function viewstudentactivities()
	{
		
		$data = array();
		$data['New_Notifications'] = New_Notifications;	
		$this->load->view(HEADER,$data);
		
		$data = array();
		$cond=array();
		
		$cond['ClassSlno']  = $this->session->userdata('ClassSlno');
		$cond['ClassSection']  = $this->session->userdata('ClassSection');
		$cond['StudentId']  = $this->session->userdata('StudentId');
		
		$total_events = $this->Commonmodel->getArchieveEvents();

		if($total_events['Events_exists']=="Yes")
			$data['events'] = 	$total_events['Event'];
		else
			$data['events'] = 	array();
			
		//get the latest event pictures
		
		$latest_event = $this->Commonmodel->getLatestPics();
		if($latest_event!='0')
		{
			$data['latest_event'] = $latest_event;
			$this->load->view('Parent/view-student-activities',$data);
		}
		else
		{
			
		}

		$this->load->view(FOOTER);
		
	}
	
	//Show all the home works till now and show the latest one first.
	
	public function showhomeworks()
	{
		
		$data = array();
		$data['New_Notifications'] = New_Notifications;	
		$this->load->view(HEADER,$data);
		
		$this->load->view('Parent/show-home-works');

		$this->load->view(FOOTER);
		
	}
	
	
	//Show all the home works till now and show the latest one first. ends here
	

	
}//class ends here
