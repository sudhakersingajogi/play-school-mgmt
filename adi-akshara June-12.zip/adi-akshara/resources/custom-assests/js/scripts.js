$(window).load(function()
{
	var par = $("td.day a").parent();
	par.css('background','#C69');
	$("td.day a").css('color','#fff');
});

$(document).ready(function() 
{

	$("#TeacherName").on('change',function() 
	{ 
		var err_cnt='0';
		
		var TeacherName = $("#TeacherName").val();
			TeacherName = $.trim(TeacherName);
		
		
		
		if(TeacherName==0)
		{
			$(".TeacherName_err").html('Select Teacher');		
			err_cnt='1';
		}
		else
			$(".TeacherName_err").html('');		
	});

	$("#ClassName").on('change',function() 
	{ 
		var ClassName = $("#ClassName").val();
			ClassSLNO = $.trim(ClassName);
		
		if( ClassSLNO=='0' )
		{
			$(".ClassName_err").html('Select class');
			err_cnt='1';
			$("#sections").html('');
		}
		else
		{
			$(".ClassName_err").html('');
			
			$.ajax({
						url:base_url+"Requestdispatcher/getsections",
						type:'POST',
						data:{"ClassSLNO":ClassSLNO},
						sendBefore:function(){  },
						success:function(resp)
						{
							resp = $.trim(resp);
							
							if(resp!='0')
							{
								resp = JSON.parse(resp);
													
								if( typeof(resp) == 'object' )	
								{
									var section_options='<option value=0>Select Section</option>';
									
									$.each(resp,function(index,val)
									{
										section_options=section_options+'<option value="'+index+'">'+val+'</option>';
										console.log(section_options);
									});
									
									$("#sections").html(section_options);
								}
								else
								{
									console.log('no');
								}
							}
						}
						
						
					});
			
				
		}
	});	


//addmore functionlaity goes here
	
	$(".addmore").on('click',function() 
	{ 
		var err_cnt='0';
		
		$(".subjects").each(function() 
		{ 
			if( $.trim( $(this).val() )=='')
			{
				err_cnt='1';
				$(this).parent().next().find('.subject_err').html('Enter subject');
			}
			else
				$(this).parent().next().find('.subject_err').html('');
			
		});
		
		if(err_cnt=='0')
		{
			var addmore_section = '<div class="form-group subjectdiv moresubjects"><label for="subjects" class="control-label col-lg-4">&nbsp;<span class="required"></span></label><div class="col-lg-3"><input class="form-control subjects" name="subjects" placeholder="Subject" /></div><div class="col-lg-2 err-msg assign-err"><span class="subject_err"></span> </div> <div class="col-lg-2 remore_subject"><span> X </span> </div></div>';
		
			$(".subjectdiv:last").after(addmore_section);
		}
			
			
	});



//remove subjects starts here

	$(document).on('click','.remore_subject',function()
	{
		if(confirm('Do you want to remove this subject'));
		$(this).parent().remove();
		
	});

//remove subjects ends here

//addmore functionlaity ends here

$(document).on('click','#assignteacher_btn,#edit_assignteacher_btn',function() 
{
	var OnClick = $(this);
	
	var edit_add= $(this).attr('edit_add');

	
	
	var err_cnt='0';
	
	var TeacherName = $("#TeacherName").val();
		TeacherName = $.trim(TeacherName);
	
	if(TeacherName=='0')
	{
		err_cnt='1';
		$(".TeacherName_err").html('Select Teacher');	
	}
	else
		$(".TeacherName_err").html('');	
	
	var ClassName = $("#ClassName").val();
			ClassSLNO = $.trim(ClassName);
		
		if( ClassSLNO=='0' )
		{
			$(".ClassName_err").html('Select class');
			err_cnt='1';
		}
		else
			$(".ClassName_err").html('');
			
	var sections = $("#sections").val();
			sections = $.trim(sections);
		
		if( sections=='0' )
		{
			$(".section_err").html('Select section');
			err_cnt='1';
		}
		else
			$(".section_err").html('');	
			
	
		var assignedSubjects = [];
			
	$(".subjects").each(function() 
		{ 
			if( $.trim( $(this).val() )=='')
			{
				err_cnt='1';
				$(this).parent().next().find('.subject_err').html('Enter subject');
			}
			else
			{
				$(this).parent().next().find('.subject_err').html('');
				var newarr = {'subject':$(this).val()};
				assignedSubjects.push(newarr);
			}
			
		});
		
		console.log(err_cnt);
		if(err_cnt=='0')			
		{
			var classteacher = 'No';
			if(edit_add=='add')
			{
				
				$(".classteacher").each(function()
				{
					if( $(this).attr('checked')=="checked" )
					{
						classteacher = $(this).val();
					}
				});
				

					$.ajax({
								url:base_url+"Requestdispatcher/asignteacher",
								type:'POST',
								data:{"TeacherName":TeacherName,"ClassSLNO":ClassSLNO,"sections":sections,"assignedSubjects":assignedSubjects,"classteacher":classteacher},
								beforeSend:function(){  OnClick.prop('disabled',true); OnClick.val('Assinging.......'); },
								success:function(resp) {
				
														///OnClick.prop('disabled',true); OnClick.val('Assinging.......');
														resp = $.trim(resp);
														
														if(resp=='1')
														{
															OnClick.prop('disabled',false); OnClick.val('Assign Teacher');
															$(".moresubjects").remove();
															
															$("form#assign_teacher_form")[0].reset();
															
												$(".assigned-submission-resp").html('<span class="text-success"><b>Teacher assigned successfully</b> </span>');
														}
														else
														{
												$(".assigned-submission-resp").html('<span class="text-danger"><b>Unable to assign teacher</b> </span>');
														}
														
									
													}
							});	//ajax ends here
			}
			else if(edit_add=='edit')
			{
				var classteacher = 'notchoosed';
					$(".classteacher").each(function()
					{
						if( $(this).attr('checked')=="checked" )
						{
							classteacher = $(this).val();
						}
				});
				
				var teacherassigned_id = $("#teacherassigned_id").val();				
					$.ajax({
								url:base_url+"Requestdispatcher/update_asignteacher",
								type:'POST',
								data:{"teacherassigned_id":teacherassigned_id,"TeacherName":TeacherName,"ClassSLNO":ClassSLNO,"sections":sections,"assignedSubjects":assignedSubjects,"classteacher":classteacher},
								beforeSend:function(){  OnClick.prop('disabled',true); OnClick.val('Updating details.......'); },
								success:function(resp) {
				
														///OnClick.prop('disabled',true); OnClick.val('Assinging.......');
														resp = $.trim(resp);
														
														if(resp=='1')
														{
															OnClick.prop('disabled',false); OnClick.val('Update details');
														//	$(".moresubjects").remove();
															
															//$("form#assign_teacher_form")[0].reset();
															
												$(".assigned-submission-resp").html('<span class="text-success"><b>Details updated successfully</b> </span>');
														}
														else
														{
												$(".assigned-submission-resp").html('<span class="text-danger"><b>Unable to update details</b> </span>');
														}
														
									
													}
							});	//ajax ends here
				
			}
		}
	

 });
 
 
 //add more students 
 
 $("#Addstudents").on('click',function() 
 {
	var TotalStudents = $("#TotalStudents").val();
		TotalStudents = $.trim(TotalStudents);
	
	var err_cnt='0';
		
		if(TotalStudents=='')
		{
			err_cnt='1';
			$(".totalstudent_err").html('check total students');
		}
		else
			$(".totalstudent_err").html('');
	
	var content='';
	
	if(err_cnt=='0')	
	{
		
		for( var i=1; i<=TotalStudents; i++)
		{
	
		content =content+'<div class="form-group studentdiv morestudents"> <label for="Student" class="control-label col-lg-4">Student:<span class="required"></span></label> <div class="col-lg-3"> <input class="form-control Students" name="Students" id="Students" placeholder="Student" /> </div> <div class="col-lg-3"> <input class="form-control RollNumber" name="RollNumber" id="RollNumber" placeholder="Rollnumber" /><span class="err-msg"></span> </div> <div class="col-lg-2 remove_students"><span> X </span> </div></div>';
		}
	
	}
	$(".studentdiv").html(content);
	
 });
 
 //add more students ends here
 

 $(document).on('keypress','.RollNumber,#TotalStudents',function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
	 {
       $(this).addClass('err-border');
	   return false;
	  }
	 else
	 	 $(this).removeClass('err-border');
   });
	

//remove students starts here

$(document).on('click','.remove_students',function()
{
	if( confirm('Do you want to remove this student') )
	{
		$(this).parent().remove();
		
		var std_total = $(".morestudents").length;
		
		$("#TotalStudents").val(std_total);
		
		
	}
	
});//remove student ends here

	$("#addstudents, #editstudent").on('click',function()
	{
		if(edit_add=='edit')
		{
			$(".RollNumber").each(function() 
			{ 
				$(this).next().html('');
			});
			
			$(".add-student-resp").html('');
		}
		
		var err_cnt='0';
		var OnClick = $(this);
		var edit_add = $(this).attr('edit_add');
		
		var ClassName = $("#ClassName").val();
			ClassName = $.trim(ClassName);

		if(ClassName=='' || ClassName=='0')
		{
			err_cnt='1';
			$(".ClassName_err").html('select class');	
		}
		else
			$(".ClassName_err").html('');	
		
		var sections = $("#sections").val();
			sections = $.trim(sections);
		
		if( sections=='' || sections=='0')
		{
			$(".section_err").html('Select section');
			err_cnt='1';
		}
		else
			$(".section_err").html('');
		
		var AcademicYear = $("#AcademicYear").val();
			AcademicYearc= $.trim(AcademicYear);
			
		if(AcademicYear=='0')
		{
			$(".academic_err").html('Academic year');
			err_cnt='1';
		}	
		else
			$(".academic_err").html('');
		
		var TotalStudents = $("#TotalStudents").val();
			TotalStudents = $.trim(TotalStudents);
		
		if(TotalStudents=='' || TotalStudents=='0')
		{
			$(".totalstudent_err").html('check total students');
			err_cnt='1';
		}
		else
			$(".totalstudent_err").html('');
		
		var classstudents=[];
		
		$(".Students").each(function() 
		{ 
			if( $.trim( $(this).val() )=='')
			{
				err_cnt='1';
				$(this).addClass('err-border');
			}
			else
			{
				$(this).removeClass('err-border');
				var newarr = {'student':$(this).val()};
				classstudents.push(newarr);
			}
			
		});
		
		
		var studentrolls=[];
		
		$(".RollNumber").each(function() 
		{ 
			if( $.trim( $(this).val() )=='')
			{
				err_cnt='1';
				$(this).addClass('err-border');
			}
			else
			{
				$(this).removeClass('err-border');
				var newarr = {'rollnumber':$(this).val()};
				studentrolls.push(newarr);
			}
			
		});
			
			
		if(err_cnt=='0')
		{
			if(edit_add=='add')
			{
				$.ajax({
						url:base_url+"Requestdispatcher/addstudents",
						type:"POST",
						data:{"ClassName":ClassName,"Section":sections,"students":classstudents,"AcademicYear":AcademicYear,"rolls":studentrolls},
						beforeSend:function(){  OnClick.prop('disabled',true); OnClick.val('Validating......'); },
						success:function(resp)
						{
							resp = $.trim(resp);
							resp = JSON.parse(resp);
							
							if(resp.rollexists=='yes')
							{
								$.each(resp.exist_rolls,function(index,val) 
								{
									$rolcnt=0;
									$(".RollNumber").each(function() 
									{ 
										$rolcnt++;
										if($rolcnt==val)
										{
											$(this).next().html('Roll number exists');
											OnClick.prop('disabled',false); 
											OnClick.val('Create students');
										}
										
									});
									
									
										
								 });
							}
							else
							{
								$(".RollNumber").each(function() 
									{ 
										$(this).next().html('');
									});
									
									$("form#add_student_form")[0].reset();
									
									OnClick.prop('disabled',false); 
									OnClick.val('Create students');
									
									$(".add-student-resp").html('<span class="text-success"><b>Students added successfully</b> </span>');
									
									$(".morestudents").remove();
									$("#sections").html('<option value="0">Select section</option>')
							}
						}
					
					});	
			}
			else if(edit_add=='edit')
			{
				
				var stdid = $("#stdid").val();
				
				$.ajax({
						url:base_url+"Requestdispatcher/updatestudent",
						type:"POST",
						data:{"stdid":stdid,"ClassName":ClassName,"Section":sections,"AcademicYear":AcademicYear,"students":classstudents,"rolls":studentrolls},
						beforeSend:function(){  OnClick.prop('disabled',true); OnClick.val('Validating......'); },
						success:function(resp)
						{
							resp = $.trim(resp);
							resp = JSON.parse(resp);
							
							if(resp.rollexists=='yes')
							{
								$.each(resp.exist_rolls,function(index,val) 
								{
									$rolcnt=0;
									$(".RollNumber").each(function() 
									{ 
										$rolcnt++;
										if($rolcnt==val)
										{
											$(this).next().html('Roll number exists');
											OnClick.prop('disabled',false); 
											OnClick.val('Create students');
										}
										
									});
									
									
										
								 });
							}
							else
							{
								$(".RollNumber").each(function() 
									{ 
										$(this).next().html('');
									});
									
									OnClick.prop('disabled',false); 
									OnClick.val('Create students');
									
									$(".add-student-resp").html('<span class="text-success"><b>Students added successfully</b> </span>');
									
							}
						}
					
					});	
			
			}
		}
		
	});


$("#RollNo").keyup(function(event){
	    
		if(event.keyCode == 13)
		{
			alert(); return false;
			$("#parentlogin").trigger('click');
	    }
});




///get the rollnumber based on section and class

	$(document).on('click',"#parentlogin",function()
	{
		var err_cnt='0';
		var OnClick=$(this);
		
		var ClassSlno = $("#ClassName").val();
			ClassSlno = $.trim(ClassSlno);
		
		if( ClassSlno == '0' )
		{
			err_cnt='1';
			$(".ClassSection_err").html("Select Class");
		}
		else
			$(".ClassSection_err").html("");
			
			
		var section	= $("#sections").val();
			section = $.trim(section);
			
		if(section=='0')
		{
			err_cnt='1';
			$(".ClassSection_err").html('Select Section');				
		}
		else
			$(".ClassSection_err").html('');
		
		var RollNo = $("#RollNo").val();
			RollNo = $.trim(RollNo);

		if( RollNo=='' || RollNo=='000' || RollNo=='00' || RollNo=='0' )
		{
			err_cnt='1';
			$(".RollNo_err").html('Enter roll number');
		}
		else
			$(".RollNo_err").html('');
			
		var Password = $("#Password").val();
			Password = $.trim(Password);
		
		if(Password=='')
		{
			err_cnt='1';
			$(".pwd_err").html("Enter password");
		}
				
		if(err_cnt=='0')
		{
			$.ajax({
						url:base_url+"Parentrequestdispatcher/parentloginvalidation",
						type:"POST",

						data:{"ClassSlno":ClassSlno,"section":section,"RollNo":RollNo,"Password":Password},
						beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Validating.....');   },
						success:function(resp)
						{
								resp = $.trim(resp);
								
								if(resp=='1')
								{
									OnClick.prop('disabled',false); OnClick.val('Redirecting.....'); 
									window.location.href=base_url+"parent-dashboard"
								}
								else if(resp=='0')
								{
									$(".Invalid-credentials").html('<div class="text-danger">Invalid credentials</div>');	
									OnClick.prop('disabled',false); 
									OnClick.val('Login');
								}
								else if(resp=='-1')
								{
									$(".Invalid-credentials").html('<div class="text-danger">Unable to fetch student details</div>');	
									OnClick.prop('disabled',false); 
									OnClick.val('Login');
								}
								
						}
						
					});
		}	
		
				
		
	});
	
	
	
	//add more hobbies
	
	$(".addmorehobbies").on('click',function() 
	{ 
		var err_cnt ='0';	
		
		var more_hobbies = '<div class="col-lg-2 Hobbies_div" style="position:relative"><input type="text" name="Hobbies" id="Hobbies" style="width:95%" class="Hobbies form-control" placeholder="Hobby" /><span hobbieide="0" class="remove_more addmore removemorehobbies" style="float:left">X</span></div>';
		
		$(".Hobbies_div").each(function()
		{  
			
			$(".succ_fail_msg").html('');
			var val = $('.Hobbies:last').val();
				val = $.trim(val);
				if(val=='')
				{
					$('.Hobbies:last').addClass('err-border');
					$('.Hobbies:last').focus();
					err_cnt='1';
				}
				else
					$('.Hobbies:last').removeClass('err-border');
				
			
		} );
	
		if(err_cnt=='0')
		{
			$(".Hobbies_div:last").after(more_hobbies);	
			$('.Hobbies:last').focus();
		}
		
		
		
	});
	
	
	//add more extracirculam activities
	
	$(".addmoreactivities").on('click',function() 
	{ 
		$(".succ_fail_msg").html('');
		var err_cnt ='0';		
		var more_activities='<div class="col-lg-2 Extra_curr_div" style="position:relative"><input type="text" name="Extra_curr" id="Extra_curr" style="width:95%" class="Extra_curr form-control" placeholder="Activity" /><span activity_ide="0" class=" remove_more addmore removemoreactivities" style="float:left">X</span></div>';
		
		var len = $(".Extra_curr_div").length;
		
		$(".Extra_curr_div").each(function()
		{  
			
			
			var val = $('.Extra_curr:last').val();
				val = $.trim(val);
				if(val=='')
				{
					$('.Extra_curr:last').focus();
					$('.Extra_curr:last').addClass('err-border');
					err_cnt='1';
				}
				else
					$('.Extra_curr:last').removeClass('err-border');
				
			
		} );
	
		if(err_cnt=='0')
		{
			$(".Extra_curr_div:last").after(more_activities);	
			$('.Extra_curr:last').focus();
		}
		
		
		
	});
	
	
	//add more Identification marks
	
	$(".addmoreIdMarks").on('click',function() 
	{ 
		$(".succ_fail_msg").html('');
		var err_cnt ='0';		
		
		var more_marks = '<div class="col-lg-2 IdMarks_div" style="position:relative"><input type="text" name="IdMarks" id="IdMarks" style="width:95%" class="IdMarks form-control" placeholder="identification Mark" /><span marksIde="0" class="remove_more addmore removemoreactivities" style="float:left">X</span></div>';

		$(".IdMarks_div").each(function()
		{  
			
			
			var val = $('.IdMarks:last').val();
				val = $.trim(val);
				if(val=='')
				{
					$('.IdMarks:last').focus();
					$('.IdMarks:last').addClass('err-border');
					err_cnt='1';
				}
				else
					$('.IdMarks:last').removeClass('err-border');
				
			
		} );
	
		if(err_cnt=='0')
		{
			$(".IdMarks_div:last").after(more_marks);	
			$('.IdMarks:last').focus();
		}
		
		
		
	});
	
	
	$(document).on('click','.remove_more',function() 
	{ 
		$(".succ_fail_msg").html('');
		if(confirm('Do you want to remove'))
		$(this).parent().remove();
	
	});





//update edit profile of a child starts here

	$(document).on('click',"#add_edit_child_profile",function()
	{
		$(".succ_fail_msg").html('');
		
		var err_cnt='0';
		var OnClick = $(this);
		
		
		var FirstName= $("#FirstName").val();
			FirstName = $.trim(FirstName);
		
		if(FirstName=='')
		{
			$("#FirstName").addClass('err-border')	;
			err_cnt='1';
		}
		else
			$('#FirstName').removeClass('err-border');
			
			
		var LastName = $("#LastName").val();
			LastName = $.trim(LastName);
			
		if(LastName=='')
		{
			$("#LastName").addClass('err-border')	;
			err_cnt='1';
		}
		else
			$(this).removeClass('err-border');
		
		var BloodGroup = $("#BloodGroup").val();
			BloodGroup = $.trim(BloodGroup);
		
		if(BloodGroup=='')
		{
			$("#BloodGroup").addClass('err-border');	
			err_cnt='1';
		}
		else
			$("#BloodGroup").removeClass('err-border');	
		
		var hobbies_arr = [];
		var hobbies_ids = [];
		var newarr = [];
		
		
		$(".Hobbies").each(function()
		{
			var hob = $(this).val();
				hob = $.trim(hob);
			
			if(hob!='')
			{
				var newarr = {'hobby':hob};
				hobbies_arr.push(newarr);
			
				var newarr ={'hobbyid':$(this).next().attr('hobbieide')};
				hobbies_ids.push(newarr);
			}
			else
			{
				err_cnt='1';
				$(this).addClass('err-border');
					
			}
			
			
			
			
			
		});
		
		
		var Extra_curr_arr = [];
		var Extra_curr_ids = [];
		var newarr = [];
		
		
		$(".Extra_curr").each(function()
		{
			
			var acti=  $(this).val();
				acti = $.trim(acti);

			if(acti!='')
			{
				var newarr = {'ExtraCircu':acti};
				Extra_curr_arr.push(newarr);
			
				var newarr ={'ExtraCircuid':$(this).next().attr('activity_ide')};
				Extra_curr_ids.push(newarr);	
			}
			else
			{
				err_cnt='1';
				$(this).addClass('err-border');
			}
			
		});
		
		
		var Moles_arr = [];
		var Moles_ids = [];
		var newarr = [];
		
		
		$(".IdMarks").each(function()
		{
			
			var acti=  $(this).val();
				acti = $.trim(acti);

			if(acti!='')
			{
				var newarr = {'Mole':acti};
				Moles_arr.push(newarr);
			
				var newarr ={'Moleid':$(this).next().attr('markside')};
				Moles_ids.push(newarr);	
			}
			else
			{
				err_cnt='1';
				$(this).addClass('err-border');
			}
			
		});
		
		
		
		if(err_cnt=='0')
		{
			var StudentId = $("#StudentId").val();

			//var data = {"FirstName":FirstName,"LastName":LastName,"BloodGroup":BloodGroup,"StudentId":StudentId,"hobbies_arr":hobbies_arr,"hobbies_ids":hobbies_ids,"Extra_curr_arr":Extra_curr_arr,"Extra_curr_ids":Extra_curr_ids,"Moles_arr":Moles_arr,"Moles_ids":Moles_ids, "profile_img":profile_img};	
			
			
			$.ajax({
					url:base_url+"Parentrequestdispatcher/updatestudentprofile",
					type:'POST',
					data:{"FirstName":FirstName,"LastName":LastName,"BloodGroup":BloodGroup,"StudentId":StudentId,"hobbies_arr":hobbies_arr,"hobbies_ids":hobbies_ids,"Extra_curr_arr":Extra_curr_arr,"Extra_curr_ids":Extra_curr_ids,"Moles_arr":Moles_arr,"Moles_ids":Moles_ids},
					beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Updating.....');   },
					success:function(resp)
					{
						resp = $.trim(resp);
						
						OnClick.prop('disabled',false); OnClick.val('Update child profile');
						
						if(resp=='0')
						{
							$(".succ_fail_msg").html('<span class="text-danger"><b>Child profile</b></span>');
						}
						else
						{
							resp = resp.split("-");
							
							var succ=0;
							var err_msg = 'Unable to ';
							if(resp[0]=='1')
							{
								succ=(succ)+1;
							}
							else
							{
								err_msg = err_msg+' Hobbies,';
							}
							
							if(resp[1]=='1')
							{
								succ=(succ)+1;
							}
							else
							{
								err_msg = err_msg+' Activities,';	
							}
							
							if(resp[2]=='1')
							{
								succ=(succ)+1;
							}
							else
							{
								err_msg = err_msg+' Identification Marks,';
							}
							
							if(succ==3)
								$(".succ_fail_msg").html('<span class="text-success"><b>Details updated successfully</b></span>');
							else
								$(".succ_fail_msg").html('<span class="text-danger"><b>'+err_msg+'</b></span>');	
						}
						
					}//successfunction ends here

					});//ajax end here

		}//err_cnt ends here

		
		
		
		
	});
		
		
//update edit profile of a child ends here


//create subjects starts here

	$("#Createsubject").on('click',function() 
	{	
		var err_cnt='0';
		
		var TotalSubjects = $("#TotalSubjects").val();
			TotalSubjects = $.trim(TotalSubjects);
		
		if(TotalSubjects=='' || TotalSubjects<1)
		{
			$(".TotalSubjects_err").html('Number of subjects');	
			err_cnt='1';
		}
		else
		{
			$(".TotalSubjects_err").html('');	
			
			
			var more_subjects = '';
			
			for(var i=0;i<TotalSubjects;i++)
			{
			
			more_subjects =more_subjects+'<div class="form-group moresubjects"> <label for="Subject" class="control-label col-lg-4">Subject:<span class="required"></span></label> <div class="col-lg-6"> <input class="form-control Subjects" name="Subject" id="Subject" placeholder="Subject" /> </div>  <div class="col-lg-2 remove_subjects"><span> X </span> </div></div>';
			}
			
			$(".subjectsdiv").html(more_subjects);
		}
		
	});

//create subjects ends here
	
	

$(document).on('click',".remove_subjects",function()
{
	$(".add-student-resp").html('');
	
	if( confirm('Do you wnat to remove this') )
	{
		$(this).parent().remove();

		var TotalSubjects = $("#TotalSubjects").val();
			TotalSubjects = $.trim(TotalSubjects);
			
			if(TotalSubjects>1)
			{
				TotalSubjects=(TotalSubjects)-1;
				$("#TotalSubjects").val(TotalSubjects);
			}
			else
			$("#TotalSubjects").val('');
	}
});


//add subjects starts here

	$(document).on('click','#addsubjects',function()
	{
		$(".add-student-resp").html('');
		var OnClick = $(this);
		
		var edit_add = $(this).attr('edit_add');
		
		var err_cnt='0';
		
		var TotalSubjects = $("#TotalSubjects").val();
			TotalSubjects = $.trim(TotalSubjects);
		TotalSubjects = parseInt(TotalSubjects);
		
		
		if(TotalSubjects=='' || TotalSubjects<1)
		{
			$(".TotalSubjects_err").html('Number of subjects');	
			err_cnt='1';
		}
		else
			$(".TotalSubjects_err").html('');	
			
		var subjects = [];
		
		$(".Subjects").each(function()
		{
			var val = $(this).val();
				val = $.trim(val);
				
				if(val=='')
				{
					$(this).addClass('err-border');
					err_cnt='1';	
				}
				else
				{
					$(this).removeClass('err-border');
					var newarr = {'subject':val};	
					subjects.push(newarr);
				}
		});
			
		
		
		if(err_cnt=='0')
		{
			$.ajax({
						url:base_url+"Requestdispatcher/addsubjects",
						type:"POST",
						data:{"subjects":subjects},
						beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Adding.....');   },
						success:function(resp)
						{
								OnClick.prop('disabled',false); OnClick.val('Add subjects');  
								
								resp = JSON.parse(resp);

								if(resp.subectExists=='Yes')
								{
									console.log(typeof(resp.subject_exsts)+":"+resp.subject_exsts);
									
									if(resp.subject_exsts.length>0)
									{
										$.each(resp.subject_exsts,function(ind,val)
											{
												
												$(".Subjects").each(function($ind,$val)
												{
													console.log( $(this).val()+":"+$ind+":"+val );
													if($ind==val)
													{
														$(this).addClass('err-border');
													}
												});
													
											});
										
											$(".add-student-resp").html('<span class="text-danger"><b>Highlighted subjects already exists</b> </span>');
											
									}// any subject already exists
									
								}
								else if(resp.subectExists=='No')
								{
									if(resp.failedtoinsert.length>0)
									{
											resp.failedtoinsert.each(function(ind,val)
											{
												
												$(".Subjects").each(function($ind,$val)
												{
													if($ind==val)
													{
														$(this).addClass('err-border');	
													}
												});
													
											});
											
											$(".add-student-resp").html('<span class="text-danger"><b>Unable to insert highlighted subjects </b> </span>');
											
									}//if any subject is failed to insert
									
									else
									{
										$(".add-student-resp").html('<span class="text-success"><b>Subjects added successfully</b> </span>');
										
										$(".moresubjects").remove();
										$("form#add_student_form")[0].reset()
									}
								
								
								}
								
						}
						
					});
		}
		
	});

//add subjects ends here

/// update subject
	
	$("#editsubject").on('click',function()
	{
		var OnClick = $(this);
		
		var err_cnt='0';
		
		var Subject = $("#Subject").val();
			Subject = $.trim(Subject);
		
		if(Subject=='')
		{
			err_cnt='1';
			$("#Subject").addClass('err-border');
			
		}
		else
		{
			$("#Subject").removeClass('err-border');
			var SubjectId= $("#SubjectId").val();
			
			$.ajax({
					url:base_url+'Requestdispatcher/updatesubject',
					type:'POST',
					data:{"SubjectName":Subject,"SubjectId":SubjectId},
					beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Updating.....');   },
					success:function(resp)
					{
						OnClick.prop('disabled',false); OnClick.val('Update subject'); 
						
						resp = JSON.parse(resp);
						
						if(resp.subectExists=="Yes") 
						{
								$("#Subject").addClass('err-border');
								$(".update-student-resp").html('<span class="text-danger"><b>Subject already exists</b></span>');
						}
						else
						{
							if(resp.subectupdated=="Yes")	
							{
								$(".update-student-resp").html('<span class="text-success"><b>Subject updated successfully</b></span>');
							}
						}
					}
				});
		}
	});

//update subject ends here 

//get the roll numbers starts here

	$(document).on('change',"#sections",function()
	{
		var err_cnt='0';
		
		var ClassName = $("#ClassName").val();
			ClassName = $.trim(ClassName);
			
		if(ClassName=='0')
		{
			err_cnt='1';
			$(".ClassName_err").html('Select Class');
		}
		
		var sections = $("#sections").val();
		var	section = $.trim(sections);
		
		if(section=='0')
		{
			err_cnt='1';
			$('.section_err').	html('Select Section');
		}
		
		if(err_cnt=='0')
		{
			
			$.ajax({
						url:base_url+'Managerequestdispatcher/getstudents',
						type:"POST",
						data:{"ClassName":ClassName,"section":section},
						success:function(resp)
						{
							resp = JSON.parse(resp);
							
							if(resp.Nodata=="Yes")
							{
								
							}
							else if(resp.Nodata=="No")
							{
								var optins='<option value="0">Select Student</option>"';
								$.each(resp.std_details,function($ind,$val)	
								{
									//console.log(resp.std_details[$ind]['Student']+" "+resp.std_details[$ind]['LastName']+" "+resp.std_details[$ind]['Roll'])
									
									optins=optins+"<option value="+resp.std_details[$ind]['StudentId']+">"+resp.std_details[$ind]['Student']+" "+resp.std_details[$ind]['LastName']+"</option>";
								});
								
								$("#Rollno").html(optins);
							}
							
						}
					
					});
				
		}
		
	});

//get the roll numbers ends here

//add a notification starts here

	$(document).on('click','#addnotification, #edittnotification',function()
	{
		
		var OnClick = $(this);
		var err_cnt='0';
		
		var edit_add = $(this).attr('edit_add');
			edit_add = $.trim(edit_add);
			
		
		var ClassName = $("#ClassName").val();
			ClassName = $.trim(ClassName);
			
		if(ClassName=='0')
		{
			err_cnt='1';
			$(".ClassName_err").html('Select Class');
		}
		else
			$(".ClassName_err").html('');
		
		var sections = $("#sections").val();
		var	section = $.trim(sections);
		
		if(section=='0')
		{
			err_cnt='1';
			$('.section_err').	html('Select Section');
		}
		else
			$('.section_err').	html('');
		
		var Rollno = $("#Rollno").val();
			student = $.trim(Rollno);
		
		if(student=='0')	
		{
			err_cnt='1';
			$(".Roll_err").html("Select Student");
		}
		else
			$(".Roll_err").html("");
			
		var Notification = $("#Notification").val();
			Notification = $.trim(Notification);

		if(Notification=='')
		{
			err_cnt='1';
			$(".Notification_err").html('Enter notification');	
		}
		else
			$(".Notification_err").html('');	
		
		
		if(err_cnt=='0')
		{
				if(edit_add=='add')
				{
					
					$.ajax({
								url:base_url+'Managerequestdispatcher/addnotification',
								type:'POST',
								data:{"ClassName":ClassName,"section":section,"student":student,"Notification":Notification},
								beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Adding.....');   },
								success:function(resp)
								{
									OnClick.prop('disabled',true); OnClick.val('Add notification'); 
									
									
									resp = $.trim(resp);
									if(resp=='0')
									$(".add-notification-to-student-resp").html('<span class="text-danger"><b>Unable to assign a notification</b></span>');
									else if(resp=='1')
									{
										$(".add-notification-to-student-resp").html('<span class="text-success"><b>Successfully assigned notification</b></span>');								$("form#add_notificationstudent_form")[0].reset();	
										$("#sections").html('<option value="0">Select Section</option>');
										$("#Rollno").html('<option value="0">Select Student</option>');
									}
									
								}//success ends here
							});//ajax ends here
						
				}
				else
				{
					var NotificationId = $("#NotificationId").val();
					
					$.ajax({
								url:base_url+'Managerequestdispatcher/updatenotification',
								type:'POST',
								data:{"NotificationId":NotificationId,"ClassName":ClassName,"section":section,"student":student,"Notification":Notification},
								beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Adding.....');   },
								success:function(resp)
								{
									OnClick.prop('disabled',false); OnClick.val('Update notification'); 
									
									resp = $.trim(resp);
									if(resp=='0')
									$(".update-notification-to-student-resp").html('<span class="text-danger"><b>Unable to update notification</b></span>');
									else if(resp=='1')
									{
										$(".update-notification-to-student-resp").html('<span class="text-success"><b>Successfully updated notification</b></span>');							
									}
									
								}//success ends here
							});//ajax ends here
					
					
				}
				
		}
		
		
	});

//add a notification ends here

//show individual notification to the parent

$(document).on('click','.newnotifications',function()
{
	
	var ide =  $(this).attr('id');
	if(ide!='')
		var collapse = "#Notif_"+ide;
	else
		var collapse = "";
	$.ajax({
				url:base_url+"Parentrequestdispatcher/setindividualnotification",
				type:'POST',
				async:false,
				data:{"collapse":collapse},
				beforeSend:function() {   },
				success:function(resp)
				{	
					window.location.href=base_url+"view-admin-notifications";
				}
			
			});//ajax ends here
	
	//$(".accordion-toggle[href='"+collapse+"']").trigger('click');
	
	
	
});

//show individual notification to the parent ends here
	
	
//notification_replybtn

$(document).on('click','.notification_replybtn',function()
{
	
	
	$("#contentdiv").removeClass('col-lg-12');
	$("#contentdiv").addClass('col-lg-7').animate({ height: "auto", width:'auro', left: "+=0", top: "20" }, "slow");
	
	
	
	$(".notification-reply-form").css('display','block');
	var addedon = $(this).attr('addedon');
	$(".notification-label").html("Notification on "+addedon);
	$("#notificationReply").focus();
});

//notification_replybtn ends hre	


//change the status

$(document).on('click','.accordion-toggle',function()
{
	var href= $(this).attr('href');
		href = $.trim(href);
		
	href= href.split("_");

	$.ajax({
				url:base_url+"Parentrequestdispatcher/updateNotificationStatus",
				type:'POST',
				async:false,
				data:{"NotificationId":href[1]},
				beforeSend:function() {   },
				success:function(resp)
				{	
					//window.location.href=base_url+"view-admin-notifications";
				}
			
			});//ajax ends here
	
});

///add a notification by parent to admin


$("#notificationToadmin").on('focus',function() { $(".notificationToadmin_err").html('');  });
	
	$("#addNotification_parent").on('click',function()
	{
		var err_cnt = '0';
		var OnClick= $(this);
		
		var notif = $("#notificationToadmin").val();
			notif = $.trim(notif);
			
			if(notif=='')
			{
				err_cnt='1';	
				$(".notificationToadmin_err").html('<span class="text-danger"><b>Notification is requried</b> </span>');
			}
			
			if(err_cnt=='0')
			{
				$.ajax({
							url:base_url+'Parentrequestdispatcher/sendnotification',
							type:"POST",
							data:{"notif":notif},
							beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Sending.....');   },
							success:function(resp)
								{
									OnClick.prop('disabled',false); OnClick.val('Send Notification'); 
									
									resp = $.trim(resp);
									if(resp=='0')
									$(".add-admin-notification-resp").html('<span class="text-danger"><b>Unable to send notification</b></span>');
									else if(resp=='1')
									{
										$(".add-admin-notification-resp").html('<span class="text-success"><b>Successfully Sent </b></span>');							
									}
									
								}//success ends here
							
						});	
						return false;
			}
			
			
	});


//add a notification by parent to admin ends here


//asign subjects to a class starts here

	$(document).on('click',"#assignsubects_btn,#update_assignsubects",function()
	{
		var err_cnt = '0';
		var OnClick = $(this);
		var edit_add = $(this).attr('edit_add');
		
		
		var ClassName = $(	"#ClassName").val();
			ClassName = $.trim(ClassName);
		
		if(ClassName=='0')
		{
			err_cnt='1';
			$(".ClassName_err").html('Select class');
		}
		else
		{
			$(".ClassName_err").html('');	
		}
		
		var subjects =$(".subjects").val();

		var assignedsubjects = [];
		
		
		$.each(subjects,function(ind,val)
		{
			var newarr = {"Subject":val };
			assignedsubjects.push(newarr);
		});
		
		
		if(err_cnt=='0')
		{
			
			if(edit_add=='add')
			{
					$.ajax({
					
							url:base_url+'Requestdispatcher/assignsubjects',
							type:"POST",
							data:{"ClassSlno":ClassName,"subjects":assignedsubjects},
							beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Assigning subjects.....');   },
							success:function(resp)
								{
									OnClick.prop('disabled',false); OnClick.val('Assign subjects to class'); 
									
									resp = $.trim(resp);
									if(resp=='0')
									$(".assigned-submission-resp").html('<span class="text-danger"><b>Unable to assign subjects</b></span>');
									else if(resp=='1')
									{
										$(".assigned-submission-resp").html('<span class="text-success"><b>Successfully assigned</b></span>');	
										$("form#assign_subjects_form")[0].reset();						
									}
									
								}//success ends here
				
				});	
			}//edit_add=='add'
			else if(edit_add=='edit')
			{
				var selectedclass = $("#selectedclass").val();
				
				
				$.ajax({
					
							url:base_url+'Requestdispatcher/updateassignedsubjects',
							type:"POST",
							data:{"selectedclass":selectedclass,"subjects":assignedsubjects},
							beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Updating subjects.....');   },
							success:function(resp)
								{
									OnClick.prop('disabled',false); OnClick.val('Update assigned subjects'); 
									
									resp = $.trim(resp);
									if(resp=='0')
									$(".assigned-submission-resp").html('<span class="text-danger"><b>Unable to assign subjects</b></span>');
									else if(resp=='1')
									{
										$(".assigned-submission-resp").html('<span class="text-success"><b>Successfully assigned</b></span>');	
										//$("form#assign_subjects_form")[0].reset();						
									}
									
								}//success ends here
				
				});	
				
				
			}
			
			
		}
			
			
	});

//asign subjects to a class ends here

//get the assigned subjects to a class

	$(".ClassName").on('change',function() 
	{ 
		var ClassName = $("#ClassName").val();
			ClassSLNO = $.trim(ClassName);
		
		if( ClassSLNO=='0' )
		{
			$(".ClassName_err").html('Select class');
			err_cnt='1';
			$("#sections").html('');
		}
		else
		{
			$(".ClassName_err").html('');
			
			$.ajax({
						url:base_url+"Requestdispatcher/getassignedsubjects",
						type:'POST',
						data:{"ClassSLNO":ClassSLNO},
						sendBefore:function(){  },
						success:function(resp)
						{
							resp = $.trim(resp);
							
							if(resp!='0')
							{
								resp = JSON.parse(resp);
													
								if( typeof(resp) == 'object' )	
								{
									var section_options='<option value=0>Select Subject</option>';
									
									$.each(resp,function(index,val)
									{
										section_options=section_options+'<option value="'+val.SubjectId+'">'+val.Subject+'</option>';
										console.log(section_options);
									});
									
									$("#subject").html(section_options);
								}
								else
								{
									console.log('no');
								}
							}
						}
						
						
					});
			
				
		}
	});	
	
	
	
	//addhomework starts here
	
	$(document).on('click','#addhomework,#updatehomework',function()
	{
		var OnClick = $(this);
		var err_cnt='0';
		var edit_add = $(this).attr('edit_add');
		
		
		var ClassName = $("#ClassName").val();
			ClassSlno = $.trim(ClassName);
		
		if(ClassSlno=='0')
		{
			err_cnt='1';
			$(".ClassName_err").html('Select class');
		}
		else
			$(".ClassName_err").html('');
		
		var sections = $("#sections").val();
			section = $.trim(sections);
		
		if(section == '0')
		{
			err_cnt='1';
			$(".section_err").html('Select section');
		}
		else
			$(".section_err").html('');
		
		var Rollno = $("#Rollno").val();
			Rollno = $.trim(Rollno);
			
		if(Rollno=='0')
		{
			err_cnt='1';
			$(".Roll_err").html('Select student');
		}
		else
			$(".Roll_err").html('');
			
		var subject = $("#subject").val();
			subject = $.trim(subject);
		
		if(subject=='0')
		{
			err_cnt='1';
			$(".subject_err").html('Select subject');
		}
		else
			$(".subject_err").html('');
		
		var homeworkdate = $("#homeworkdate").val();
			homeworkdate = $.trim(homeworkdate);

		if(homeworkdate=='')
		{
			err_cnt='1';
			$(".homeworkdate_err").html('Home work date');
		}
		else
			$(".homeworkdate_err").html('');
			
		var homework = $("#homework").val();
			homework = $.trim(homework);

		if(homework=='')
		{
			err_cnt='1';
			$(".homework_err").html('Enter Home Work');
		}
		else
			$(".homework_err").html('');
			

		if(err_cnt=='0')	
		{
			
			if(edit_add=='add')
			{
					$.ajax({
							url:base_url+"Managerequestdispatcher/addhomework",
							type:"POST",
							data:{"ClassSlno":ClassSlno,"ClassSection":section,"StudentId":Rollno,"SubjectId":subject,"HomeWorkOn":homeworkdate,"HomeWork":homework},
							beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Adding home work....');   },
							success:function(resp)
							{
								resp=$.trim(resp);
								
								 OnClick.prop('disabled',false); OnClick.val('Add Home-Work');   
								
								if(resp=='1')
								{
									$("form#add_homework_form")[0].reset();
									$(".add-home-work-resp").html('<span class="text-success"><b>Home work assigned suucessfully</b></span>');
									$("#sections").html('<option value="0">Select Section</option>');
									$("#Rollno").html('<option value="0">Select Student</option>');
									$("#subject").html('<option value="0">Select Subject</option>');
								}
								else
								{
									$(".add-home-work-resp").html('<span class="text-danger"><b>Unable to assign home work</b></span>');
								}
								
								
							}//success ends here
				});	//ajax ends here
			}
			else if(edit_add=='edit')
			{
				
				var assignedhomeworkid = $("#assignedhomeworkid").val();
				
				
				$.ajax({
							url:base_url+"Managerequestdispatcher/updatehomework",
							type:"POST",
							data:{"assignedhomeworkid":assignedhomeworkid,"ClassSlno":ClassSlno,"ClassSection":section,"StudentId":Rollno,"SubjectId":subject,"HomeWorkOn":homeworkdate,"HomeWork":homework},
							beforeSend:function() { OnClick.prop('disabled',true); OnClick.val('Adding home work....');   },
							success:function(resp)
							{
								resp=$.trim(resp);
								
								 OnClick.prop('disabled',false); OnClick.val('Add Home-Work');   
								
								if(resp=='1')
								{
									$(".add-home-work-resp").html('<span class="text-success"><b>Home work updated suucessfully</b></span>');
								}
								else
								{
									$(".add-home-work-resp").html('<span class="text-danger"><b>Unable to update home work</b></span>');
								}
								
								
							}//success ends here
				});	//ajax ends here
				
			}
		}
			
			
			
	});
	
	// addhomework ends here	


//get the event pics and show it in the modal popup

$(document).on('click','.getEventpics',function()
{
	var EventID = $(this).attr('id');
		//alert(EventID);
		var OnClick = $(this);
		
	
	var Event_title = $(this).parent().parent().find('.event').html();
		
	$(".eventName").html(Event_title);
	
	
	$.ajax({
			url:base_url+'Managerequestdispatcher/geteventpics',
			type:"POST",
			data:{"EventID":EventID},
			beforeSend:function() { OnClick.removeClass('btn-primary'); OnClick.addClass('btn-success'); OnClick.html('Getting event pics....');   },
			success:function(resp)
			{
					 OnClick.removeClass('btn-success'); OnClick.addClass('btn-primary'); OnClick.html('View Event Pics');
					 
					 resp = $.trim(resp);
					
					resp = JSON.parse(resp); 
					
					var myCarousel = '<div class="carousel-inner">';
      

					
					
					if(resp.Datavailable=='yes')
					{
						var imgCnt=0;
						
						$.each(resp.Eventpics,function()
						{
							console.log(resp.Eventpics[imgCnt]);
							
							if(imgCnt==0)
							{
							myCarousel=myCarousel+'<div class="item active EventId_'+resp.Eventpics[imgCnt].ActivityPicId+'"><i class="fa fa-trash-o car_del eventpicdel" id="EventId_'+resp.Eventpics[imgCnt].ActivityPicId+'"></i><img src="'+resp.Eventpics[imgCnt].Picture+'" alt="" style="height:500px;" /></div>';
							}
							else
							{
							myCarousel=myCarousel+'<div class="item EventId_'+resp.Eventpics[imgCnt].ActivityPicId+'"><i class="fa fa-trash-o car_del eventpicdel" id="EventId_'+resp.Eventpics[imgCnt].ActivityPicId+'"></i><img src="'+resp.Eventpics[imgCnt].Picture+'" alt="" style="height:500px;" /></div>';
							}
							
							imgCnt = (imgCnt)+1;
						});
						
						
						
						myCarousel =myCarousel+'</div><a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span><span class="sr-only">Previous</span></a>    <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span><span class="sr-only">Next</span></a>';
						
						$("#myCarousel").html(myCarousel);
						
					}
			}
			});
		
	
	
});


$(document).on('click','.eventpicdel',function()
{
	
	if(confirm('Do you want to delte'))
	{
		var EventId = $(this).attr('id');
		
		$.ajax({
				url:base_url+'Managerequestdispatcher/DeleteEventpic',
				type:"POST",
				data:{"EventId":EventId},
				success:function(resp)
				{
					resp = $.trim(resp);
					if(resp=="1")
						$("."+EventId).html("<h2 style='height:500px; text-align:center; line-height:500px'>Image deleted</h2>");
					
				}
			
			});
	}
	
});


//get the event pics and show it in the modal popup


//toggle the archieves

$(".archieves-list div span").on('click',function()
{
	var par = $(this).parent();
	
	
	if(par.find('ul').css('display')=='block')
	{
			//$(this).children().find('ul').css('display','none');		
			par.find('ul').slideUp('slow');
	}
	else
	{
		$(".archieves-list div").find('ul').slideUp('slow');
//		$(this).children().find('ul').css('display','block').slideDown('slow');
		par.find('ul').slideDown('slow');
	}
	
	
	
})



// profile image upload for student 

$(function() {
$("#imageUpload").change(function() {
$("#message").empty(); // To remove the previous error message
var file = this.files[0];
var imagefile = file.type;
var match= ["image/jpeg","image/png","image/jpg"];
if(!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
{
	
$("#message").html("Only jpeg, jpg and png Images type allowed");
return false;
}
else
{
	
var reader = new FileReader();
reader.onload = imageIsLoaded;
reader.readAsDataURL(this.files[0]);
}
});
});




//$("#file").on('change',function() 
$("#uploadimage").on('submit',function(e)
{ 

$.ajax({
		url:base_url+"Parentrequestdispatcher/changeprofilepic", // Url to which the request is send
		type: "POST",             // Type of request to be send, called as method
		data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		contentType: false,       // The content type used when sending data to the server.
		cache: false,             // To unable request pages to be cached
		processData:false,        // To send DOMDocument or non processed data file it is set to false
		success: function(data)   // A function to be called if request succeeds
		{
			$('#loading').hide();
			$("#message").html(data);
			return false;
		
		}
});

});

// profile image uplod for studnet ends here

$(document).on('click',".Event-Name",function()
{
	var eventide = $(this).attr('id');
		eventide = $.trim(eventide);
		eventide = "Event_"+eventide;


	$.ajax({
				url:'Parentrequestdispatcher/getEventbasedpics',
				type:"POST",
				data:{"eventid":eventide},
				beforeSend:function() { $(".loader").css('display','block');   },
				success:function(resp)
				{
					$(".loader").css('display','none');	
					resp = $.trim(resp);
					resp = JSON.parse(resp);
					
					if(resp.Pic_exists=="no")
					{
						
					}
					else if(resp.Pic_exists=="yes")
					{
						var cnt=0;
						var picdivs ='';
						$.each(resp.Eventpics,function()
						{
							
//							console.log(resp.Eventpics[cnt]['Picture']);
							
							//eventPictures
							
							picdivs = picdivs+'<div class="pic-container col-md-4">';
								picdivs = picdivs+'<a class="example-image-link" href="'+resp.Eventpics[cnt]['Picture']+'" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">';
								picdivs = picdivs+'<img src="'+resp.Eventpics[cnt]['Picture']+'" /></a> <div class="download"><a href="'+resp.Eventpics[cnt]['Picture']+'" download> <i class="fa fa-cloud-download"></i> Download</a></div></div>';
							cnt = (cnt)+1;
							console.log(picdivs);
						});
						
						$(".eventPictures").html(picdivs);
						
					}
				}
		
		});
	
});



$(document).on('click','.day a',function()
{
	return false;
	
});

$(document).on('click',".calendar .day",function()
{
	
	$(".err-msg").html('');
	$(".addexam_resp").html("");
	$(".addceleb_resp").html('');
	
	var date = $(this).text();
		date = $.trim(date);
	
	var pathname = window.location.pathname; // Returns path only
	var url      = window.location.href; 
	
	var pathname = pathname.split("/");
	
	if(pathname[2] =="view-celebrations")
	{
		var dtd = $(this).html();
		
		console.log( dtd.indexOf("<a"));
		
		if( dtd.indexOf("<a") == 0 )
			{
				var dtd = $(this).find('a').attr('href');
				
				//console.log(dtd);
				var month_day = $(this).parent().parent().parent().find('th').text();
				month_day = month_day.replace(" ","-",month_day);
			
				//$(".cel_date").val(date+'-'+month_day);
				var dated =  date+'-'+month_day;
				
				$dtd = dtd.split("||||");
				var CelebId = $dtd[1];
				
				$.ajax({
							
							url:'Schedulingdispatcher/getcelebratation',
							type:"POST",
							data:{"CelebId":CelebId},
							beforeSend:function() { $(".loader").css('display','block');   },
							success:function(resp)
							{
								resp = $.trim(resp);
								if(resp!='0')
								{
									$(".modal").css('display','block');
									$("#myModal").addClass('in');
									
									$("#myModal").css({'background':'rgba(0, 0, 0, 0.72)'});
									
									$(".event_da .form-control").css({'width':'75%'});
									$(".event_da").css({'margin-bottom':'30px'});	
									$(".event_da label").css({'float': 'left','margin-right': '20px',"width":'20%'});
									$(".err-msg").css({'float':'right','margin-right':'7px'});
									
									
									resp = JSON.parse(resp);
									
									$.each(resp,function()
									{ 
									//	console.log(resp[0].Celebration_Date);
										
										$(".cel_date").val(resp[0].Celebration_Date);
										$(".celebration").val(resp[0].Celebration_Text);
										$("#CelebId").val(resp[0].CelebId);
										
									});
									
									
								}
							}
				
						});//ajax ends here
			}
			

	}
	else
	{
		
			if(date!='')
			{
				var month_day = $(this).parent().parent().parent().find('th').text();
				month_day = month_day.replace(" ","-",month_day);
			
			$(".cel_date").val(date+'-'+month_day);
			
			
			
			$(".modal").css('display','block');
			$("#myModal").addClass('in');
			
			$("#myModal").css({'background':'rgba(0, 0, 0, 0.72)'});
			
			$(".event_da .form-control").css({'width':'75%'});
		$(".event_da").css({'margin-bottom':'30px'});	
			$(".event_da label").css({'float': 'left','margin-right': '20px',"width":'20%'});
			$(".err-msg").css({'float':'right','margin-right':'7px'});
			}
	}
});

$(document).on('click','.close',function()
{
	$(".modal").css('display','none');
	$("#myModal").removeClass('in');
});



$(document).on('click','.celebrationbtn, .updatecelebrationbtn',function()
{
	var addedit = $(this).attr('addedit');
	
	
	var err_cnt = '0';
	var OnClick = $(this);
	
	var celebration = $(".celebration").val();
		celebration = $.trim(celebration);
		
	var cel_date = $(".cel_date").val();	
		cel_date = $.trim(cel_date);
		
	if(cel_date=='')
	{
		err_cnt='1';
	}
	if(celebration=='')
	{
		err_cnt='1';
		$(".err-msg").html('Enter Celebration');
		$(".celebration").focus();
	}
	
	if(err_cnt=='0')
	{
		if(addedit=="add")
		{
				$.ajax({
							url:base_url+'Schedulingdispatcher/addCelebration',
							type:"POST",
							data:{"celebration":celebration,"cel_date":cel_date},
							success:function(resp)
							{
								resp=$.trim(resp);
								
								if(resp=='1')
								{
									$(".addceleb_resp").html("<span class='text-success'><b>New celebration added successfuly</b></span>");
									$("form#add-celebrationform")[0].reset();
								}
								else
								{
									$(".addceleb_resp").html("<span class='text-danger'><b>unable to add new celebration</b></span>");
								}
							}
						});
		}
		else
		{
			var CelebId = $("#CelebId").val();
			
			$.ajax({
							url:base_url+'Schedulingdispatcher/updateCelebration',
							type:"POST",
							data:{"CelebId":CelebId,"celebration":celebration,"cel_date":cel_date},
							success:function(resp)
							{
								resp=$.trim(resp);
								
								if(resp=='1')
								{
									$(".addceleb_resp").html("<span class='text-success'><b>Updated successfuly</b></span>");
								}
								else
								{
									$(".addceleb_resp").html("<span class='text-danger'><b>unable to update</b></span>");
								}
							}
						});
			
		}
	}
			
});



// addexamBtn validation starts here

$(document).on('click','.addexamBtn',function()
{
	var err_cnt='0';
	var OnClick = $(this);
	
	
	var ClassName = $("#ClassName").val();
		ClassName = $.trim(ClassName);
	
	if(ClassName=='0')
	{	
		err_cnt='1';
		$(".classErr").html('Select Class');
	}
	else
		$(".classErr").html('');
		

var sections = $("#sections").val();
	sections = $.trim(sections);

if(sections=='0')
{
	err_cnt='1';
	$(".sectionErr").html("Select Section");	
}
else
	$(".sectionErr").html("");
	
var subject = $("#subject").val();
	subject = $.trim(subject);

if(subject=='0')
{
	var err_cnt='1';
	$(".subjectErr").html("Select Subject");
}
else
	$(".subjectErr").html("");
	
var ExamName = $("#ExamName").val();
	ExamName = $.trim(ExamName);
	
	if(ExamName=='0')	
	{
		$(".examErr").html("Select Exam Type");
		err_cnt='1';
	}
	else
		$(".examErr").html("");
		
	if( err_cnt=='0')		
	{
		var cel_date = $(".cel_date").val();
		console.log(cel_date);
		
		$.ajax({
				
				url:base_url+'Schedulingdispatcher/addExam',
				type:"POST",
				data:{"ExamDate":cel_date,"ClassName":ClassName,"ClassSection":sections,"Subject":subject,"ExamName":ExamName},
				success:function(resp)
				{
					resp = $.trim(resp);
					
					if(resp=="1")
					{
						$("form#add-exam-form")[0].reset();
						
						$(".addexam_resp").html("<div class='alert alert-success'><b>Exam scheduled successfully</b></div>");	
					}
					else if(resp=='0')
						$(".addexam_resp").html("<div class='alert alert-danger'><b>Failed to add exam schedule</b></div>");	
					else if(resp=='-1')
						$(".addexam_resp").html("<div class='alert alert-warning' style='color:#000'><b>This exam already scheduled</b></div>");	
					
				}
				
				});//ajax ends here
				
	}//if err_cnt==0 ends here
		
	
	
});

// addexamBtn validation ends here



}); //document ready ends hre